<?php
/**
 * Plugin Name:       TOKCONSULT Forms
 * Description:       Receives the Contact form and the email sign-up forms built into the TOKCONSULT pages. Emails each message to you, keeps a copy under Forms in the dashboard, and exports to CSV. No form builder needed.
 * Version:           1.0.1
 * Author:            TOKCONSULT
 * Requires at least: 6.0
 * Requires PHP:      7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class TOKF {

	const OPT = 'tokf_settings';
	const VER = '1.0.0';

	public static function defaults() {
		return array(
			'notify_email' => 'info@tokconsult.com.ng',
			'notify_news'  => 1,
			'autoreply'    => 1,
			'rate_limit'   => 5,
		);
	}

	public static function opt( $k ) {
		$all = wp_parse_args( (array) get_option( self::OPT, array() ), self::defaults() );
		return $all[ $k ] ?? null;
	}

	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'tokf_entries';
	}

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'admin_actions' ) );
		add_action( 'plugins_loaded', array( __CLASS__, 'maybe_upgrade' ) );
		add_action( 'wp_footer', array( __CLASS__, 'footer_js' ), 50 );
	}

	/* ---------- front-end script ---------- */

	/** Printed by the plugin (not pasted in the page) because WordPress rewrites && inside page content, which breaks inline scripts. */
	public static function footer_js() {
		if ( is_admin() || ! is_singular() ) {
			return;
		}
		$content = (string) get_post_field( 'post_content', get_queried_object_id() );
		if ( false === strpos( $content, 'data-tokform' ) ) {
			return;
		}
		echo '<script id="tokf-js">' . self::JS . '</script>' . "\n"; // phpcs:ignore
	}

	const JS = <<<'TOKFJS'
(function(){
  var t0=Date.now();
  function post(url,data){return fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},credentials:'omit',body:JSON.stringify(data)});}
  document.querySelectorAll('[data-tokform]').forEach(function(f){
    var btn=f.querySelector('[data-tokf-send]'),msg=f.querySelector('.tokf-msg');if(!btn)return;
    var label=btn.textContent;
    function val(n){var e=f.querySelector('[name="'+n+'"]');return e?e.value.trim():'';}
    function say(t){msg.textContent=t;}
    function send(){
      var req=f.querySelectorAll('[required]');
      for(var i=0;i<req.length;i++){var e=req[i];if(!e.value.trim()||(e.type==='email'&&!e.checkValidity())){var l=e.closest('label');say((e.type==='email'?'Please enter a valid email address.':'Please fill in: '+(l?l.firstChild.textContent.trim():'this field')+'.'));e.focus();return;}}
      var data={type:f.getAttribute('data-tokform'),name:val('name'),business:val('business'),email:val('email'),phone:val('phone'),budget:val('budget'),message:val('message'),website:val('website'),elapsed:Date.now()-t0,page:location.href.split('#')[0]};
      btn.disabled=true;btn.textContent='Sending…';say('');
      post('/wp-json/tokforms/v1/submit',data).then(function(r){if(r.status===404)return post('/?rest_route=/tokforms/v1/submit',data);return r;})
      .then(function(r){return r.json().then(function(j){return{ok:r.ok,j:j};});})
      .then(function(x){
        say((x.j&&x.j.message)||(x.ok?'Thank you!':'Something went wrong. Please try again.'));
        if(x.ok){f.querySelectorAll('input,textarea,select').forEach(function(e){if(e.name!=='website'){e.value='';}});}
      })
      .catch(function(){say('We couldn’t send that. Check your connection, or chat with us on WhatsApp: +234 902 809 5483.');})
      .then(function(){btn.disabled=false;btn.textContent=label;});
    }
    btn.addEventListener('click',send);
    f.addEventListener('keydown',function(e){if(e.key==='Enter'&&e.target.tagName==='INPUT'){e.preventDefault();send();}});
  });
})();
TOKFJS;

	/* ---------- storage ---------- */

	public static function activate() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$t = self::table();
		$c = $wpdb->get_charset_collate();
		dbDelta(
			"CREATE TABLE {$t} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			created_at datetime NOT NULL,
			type varchar(20) NOT NULL,
			name varchar(120) NOT NULL DEFAULT '',
			business varchar(160) NOT NULL DEFAULT '',
			email varchar(160) NOT NULL,
			phone varchar(40) NOT NULL DEFAULT '',
			budget varchar(60) NOT NULL DEFAULT '',
			message text NULL,
			page varchar(255) NOT NULL DEFAULT '',
			ip_hash char(64) NOT NULL DEFAULT '',
			is_read tinyint(1) NOT NULL DEFAULT 0,
			PRIMARY KEY  (id),
			KEY type_created (type, created_at),
			KEY email (email)
			) {$c};"
		);
		update_option( 'tokf_db', self::VER );
	}

	public static function maybe_upgrade() {
		if ( get_option( 'tokf_db' ) !== self::VER ) {
			self::activate();
		}
	}

	/* ---------- endpoint ---------- */

	public static function routes() {
		register_rest_route(
			'tokforms/v1',
			'/submit',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'submit' ),
				'permission_callback' => '__return_true',
			)
		);
	}

	private static function ip_hash() {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		return hash( 'sha256', $ip . wp_salt( 'nonce' ) );
	}

	private static function fail( $msg, $code = 400 ) {
		return new WP_REST_Response( array( 'ok' => false, 'message' => $msg ), $code );
	}

	/** Pure validation, kept separate so it can be tested. Returns array( $clean, $error ). */
	public static function validate( $in ) {
		$type = isset( $in['type'] ) && 'contact' === $in['type'] ? 'contact' : 'newsletter';
		$c    = array(
			'type'     => $type,
			'name'     => mb_substr( sanitize_text_field( (string) ( $in['name'] ?? '' ) ), 0, 120 ),
			'business' => mb_substr( sanitize_text_field( (string) ( $in['business'] ?? '' ) ), 0, 160 ),
			'email'    => mb_substr( sanitize_email( (string) ( $in['email'] ?? '' ) ), 0, 160 ),
			'phone'    => mb_substr( preg_replace( '/[^0-9+ ()-]/', '', (string) ( $in['phone'] ?? '' ) ), 0, 40 ),
			'budget'   => mb_substr( sanitize_text_field( (string) ( $in['budget'] ?? '' ) ), 0, 60 ),
			'message'  => mb_substr( sanitize_textarea_field( (string) ( $in['message'] ?? '' ) ), 0, 5000 ),
			'page'     => mb_substr( esc_url_raw( (string) ( $in['page'] ?? '' ) ), 0, 255 ),
		);
		// Spam traps: a hidden field people never see, and a form sent faster than a person can type.
		if ( ! empty( $in['website'] ) || ( isset( $in['elapsed'] ) && (int) $in['elapsed'] < 2500 ) ) {
			return array( null, 'spam' );
		}
		if ( ! is_email( $c['email'] ) ) {
			return array( null, 'Please enter a valid email address.' );
		}
		if ( 'contact' === $type ) {
			if ( '' === $c['name'] ) {
				return array( null, 'Please enter your name.' );
			}
			if ( mb_strlen( trim( $c['message'] ) ) < 5 ) {
				return array( null, 'Please tell us a little about what you need.' );
			}
		}
		return array( $c, null );
	}

	public static function submit( WP_REST_Request $req ) {
		$in = $req->get_json_params();
		if ( ! is_array( $in ) ) {
			$in = $req->get_body_params();
		}
		list( $c, $err ) = self::validate( (array) $in );
		if ( 'spam' === $err ) {
			// Look successful to bots, store nothing.
			return new WP_REST_Response( array( 'ok' => true, 'message' => 'Thank you.' ), 200 );
		}
		if ( $err ) {
			return self::fail( $err );
		}

		$ip  = self::ip_hash();
		$key = 'tokf_rl_' . substr( $ip, 0, 32 );
		$n   = (int) get_transient( $key );
		if ( $n >= (int) self::opt( 'rate_limit' ) ) {
			return self::fail( 'You’ve sent several messages in the last hour. Please try again later, or chat with us on WhatsApp.', 429 );
		}
		set_transient( $key, $n + 1, HOUR_IN_SECONDS );

		global $wpdb;
		if ( 'newsletter' === $c['type'] ) {
			$exists = $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . self::table() . ' WHERE type = %s AND email = %s LIMIT 1', 'newsletter', $c['email'] ) ); // phpcs:ignore
			if ( $exists ) {
				return new WP_REST_Response( array( 'ok' => true, 'message' => 'You’re already subscribed. Thank you!' ), 200 );
			}
		}

		$wpdb->insert( // phpcs:ignore
			self::table(),
			array(
				'created_at' => current_time( 'mysql' ),
				'type'       => $c['type'],
				'name'       => $c['name'],
				'business'   => $c['business'],
				'email'      => $c['email'],
				'phone'      => $c['phone'],
				'budget'     => $c['budget'],
				'message'    => $c['message'],
				'page'       => $c['page'],
				'ip_hash'    => $ip,
			)
		);

		self::notify( $c );

		$msg = 'contact' === $c['type']
			? 'Thank you, ' . ( $c['name'] ? strtok( $c['name'], ' ' ) : 'we got it' ) . '. We’ve received your message and will reply within one working day.'
			: 'You’re subscribed. Thank you!';
		return new WP_REST_Response( array( 'ok' => true, 'message' => $msg ), 200 );
	}

	/* ---------- email ---------- */

	private static function notify( $c ) {
		$to = self::opt( 'notify_email' );
		if ( $to && ( 'contact' === $c['type'] || self::opt( 'notify_news' ) ) ) {
			if ( 'contact' === $c['type'] ) {
				$subject = 'New enquiry from ' . $c['name'] . ( $c['business'] ? ' (' . $c['business'] . ')' : '' );
				$rows    = array(
					'Name'           => $c['name'],
					'Business'       => $c['business'],
					'Email'          => $c['email'],
					'WhatsApp'       => $c['phone'],
					'Budget'         => $c['budget'],
					'What they need' => $c['message'],
					'Sent from'      => $c['page'],
				);
			} else {
				$subject = 'New email sign-up: ' . $c['email'];
				$rows    = array( 'Email' => $c['email'], 'Signed up on' => $c['page'] );
			}
			$html = '<div style="font-family:Arial,sans-serif;font-size:15px;color:#121B32"><h2 style="font-size:18px;margin:0 0 12px">' . esc_html( $subject ) . '</h2><table cellpadding="6" style="border-collapse:collapse">';
			foreach ( $rows as $k => $v ) {
				if ( '' !== (string) $v ) {
					$html .= '<tr><td style="color:#4A5266;vertical-align:top;white-space:nowrap"><strong>' . esc_html( $k ) . '</strong></td><td>' . nl2br( esc_html( $v ) ) . '</td></tr>';
				}
			}
			$html   .= '</table><p style="color:#4A5266;font-size:13px;margin-top:16px">Reply to this email to answer them directly. All messages are saved under Forms in your WordPress dashboard.</p></div>';
			$headers = array( 'Content-Type: text/html; charset=UTF-8', 'Reply-To: ' . ( $c['name'] ? $c['name'] . ' ' : '' ) . '<' . $c['email'] . '>' );
			wp_mail( $to, $subject, $html, $headers );
		}

		if ( 'contact' === $c['type'] && self::opt( 'autoreply' ) ) {
			$first = $c['name'] ? strtok( $c['name'], ' ' ) : 'there';
			$body  = '<div style="font-family:Arial,sans-serif;font-size:15px;line-height:1.6;color:#121B32">'
				. '<p>Hi ' . esc_html( $first ) . ',</p>'
				. '<p>Thank you for contacting TOKCONSULT. We’ve received your message and will reply within one working day.</p>'
				. '<p>If it’s urgent, chat with us on WhatsApp: <a href="https://wa.link/k3be0i">+234 902 809 5483</a>, or book a free 30-minute call: <a href="https://calendly.com/tokcdigital/30min">calendly.com/tokcdigital/30min</a>.</p>'
				. '<p>The TOKCONSULT team<br><a href="https://tokconsult.com.ng/">tokconsult.com.ng</a></p></div>';
			$headers = array( 'Content-Type: text/html; charset=UTF-8' );
			if ( $to ) {
				$headers[] = 'Reply-To: TOKCONSULT <' . $to . '>';
			}
			wp_mail( $c['email'], 'We’ve received your message', $body, $headers );
		}
	}

	/* ---------- admin ---------- */

	public static function menu() {
		global $wpdb;
		$unread = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . self::table() . " WHERE type = 'contact' AND is_read = 0" ); // phpcs:ignore
		$label  = 'Forms' . ( $unread ? ' <span class="awaiting-mod">' . $unread . '</span>' : '' );
		add_menu_page( 'TOKCONSULT Forms', $label, 'manage_options', 'tokf', array( __CLASS__, 'entries_page' ), 'dashicons-email-alt', 26 );
		add_submenu_page( 'tokf', 'Messages', 'Messages', 'manage_options', 'tokf', array( __CLASS__, 'entries_page' ) );
		add_submenu_page( 'tokf', 'Settings', 'Settings', 'manage_options', 'tokf-settings', array( __CLASS__, 'settings_page' ) );
	}

	public static function admin_actions() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		register_setting( 'tokf', self::OPT, array( 'sanitize_callback' => array( __CLASS__, 'clean_settings' ) ) );

		if ( isset( $_GET['tokf_export'] ) && check_admin_referer( 'tokf_export' ) ) { // phpcs:ignore
			self::export( 'newsletter' === $_GET['tokf_export'] ? 'newsletter' : 'contact' ); // phpcs:ignore
		}
		if ( isset( $_GET['tokf_delete'] ) && check_admin_referer( 'tokf_delete' ) ) { // phpcs:ignore
			global $wpdb;
			$wpdb->delete( self::table(), array( 'id' => absint( $_GET['tokf_delete'] ) ) ); // phpcs:ignore
			wp_safe_redirect( remove_query_arg( array( 'tokf_delete', '_wpnonce' ) ) );
			exit;
		}
	}

	public static function clean_settings( $in ) {
		$d = self::defaults();
		return array(
			'notify_email' => sanitize_email( $in['notify_email'] ?? $d['notify_email'] ),
			'notify_news'  => empty( $in['notify_news'] ) ? 0 : 1,
			'autoreply'    => empty( $in['autoreply'] ) ? 0 : 1,
			'rate_limit'   => max( 1, min( 50, absint( $in['rate_limit'] ?? $d['rate_limit'] ) ) ),
		);
	}

	private static function export( $type ) {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT created_at, name, business, email, phone, budget, message, page FROM ' . self::table() . ' WHERE type = %s ORDER BY created_at DESC', $type ), ARRAY_A ); // phpcs:ignore
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=tokconsult-' . $type . '-' . gmdate( 'Y-m-d' ) . '.csv' );
		$out = fopen( 'php://output', 'w' );
		fwrite( $out, "\xEF\xBB\xBF" );
		fputcsv( $out, array( 'Date', 'Name', 'Business', 'Email', 'WhatsApp', 'Budget', 'Message', 'Page' ) );
		foreach ( $rows as $r ) {
			// Stop spreadsheet formula injection.
			$r = array_map( function ( $v ) { return preg_match( '/^[=+\-@]/', (string) $v ) ? "'" . $v : $v; }, $r );
			fputcsv( $out, array_values( $r ) );
		}
		fclose( $out );
		exit;
	}

	public static function entries_page() {
		global $wpdb;
		$type = ( isset( $_GET['view'] ) && 'newsletter' === $_GET['view'] ) ? 'newsletter' : 'contact'; // phpcs:ignore
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE type = %s ORDER BY created_at DESC LIMIT 200', $type ) ); // phpcs:ignore
		if ( 'contact' === $type ) {
			$wpdb->query( 'UPDATE ' . self::table() . " SET is_read = 1 WHERE type = 'contact' AND is_read = 0" ); // phpcs:ignore
		}
		$base = admin_url( 'admin.php?page=tokf' );
		?>
		<div class="wrap">
			<h1 class="wp-heading-inline">TOKCONSULT Forms</h1>
			<a class="page-title-action" href="<?php echo esc_url( wp_nonce_url( add_query_arg( 'tokf_export', $type, $base ), 'tokf_export' ) ); ?>">Export CSV</a>
			<h2 class="nav-tab-wrapper">
				<a href="<?php echo esc_url( $base ); ?>" class="nav-tab <?php echo 'contact' === $type ? 'nav-tab-active' : ''; ?>">Contact messages</a>
				<a href="<?php echo esc_url( add_query_arg( 'view', 'newsletter', $base ) ); ?>" class="nav-tab <?php echo 'newsletter' === $type ? 'nav-tab-active' : ''; ?>">Email sign-ups</a>
			</h2>
			<?php if ( ! $rows ) : ?>
				<p>Nothing yet. New <?php echo 'contact' === $type ? 'messages' : 'sign-ups'; ?> will appear here.</p>
			<?php else : ?>
			<table class="widefat striped">
				<thead><tr><th>Date</th><?php if ( 'contact' === $type ) : ?><th>Name / business</th><?php endif; ?><th>Email</th><?php if ( 'contact' === $type ) : ?><th>WhatsApp</th><th>Budget</th><th>Message</th><?php endif; ?><th>Page</th><th></th></tr></thead>
				<tbody>
				<?php foreach ( $rows as $r ) : ?>
					<tr>
						<td><?php echo esc_html( mysql2date( 'j M Y, g:ia', $r->created_at ) ); ?></td>
						<?php if ( 'contact' === $type ) : ?><td><strong><?php echo esc_html( $r->name ); ?></strong><br><?php echo esc_html( $r->business ); ?></td><?php endif; ?>
						<td><a href="mailto:<?php echo esc_attr( $r->email ); ?>"><?php echo esc_html( $r->email ); ?></a></td>
						<?php if ( 'contact' === $type ) : ?>
							<td><?php echo esc_html( $r->phone ); ?></td>
							<td><?php echo esc_html( $r->budget ); ?></td>
							<td style="max-width:420px"><?php echo nl2br( esc_html( $r->message ) ); ?></td>
						<?php endif; ?>
						<td><?php echo esc_html( wp_parse_url( $r->page, PHP_URL_PATH ) ); ?></td>
						<td><a href="<?php echo esc_url( wp_nonce_url( add_query_arg( array( 'tokf_delete' => $r->id, 'view' => $type ), $base ), 'tokf_delete' ) ); ?>" onclick="return confirm('Delete this entry?');">Delete</a></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			<p class="description">Showing the latest 200. Export CSV downloads everything.</p>
			<?php endif; ?>
		</div>
		<?php
	}

	public static function settings_page() {
		$o = wp_parse_args( (array) get_option( self::OPT, array() ), self::defaults() );
		?>
		<div class="wrap">
			<h1>Form settings</h1>
			<form method="post" action="options.php">
				<?php settings_fields( 'tokf' ); ?>
				<table class="form-table" role="presentation">
					<tr><th scope="row"><label for="tokf-to">Send messages to</label></th><td><input id="tokf-to" type="email" class="regular-text" name="<?php echo esc_attr( self::OPT ); ?>[notify_email]" value="<?php echo esc_attr( $o['notify_email'] ); ?>"></td></tr>
					<tr><th scope="row">Email me about sign-ups</th><td><label><input type="checkbox" name="<?php echo esc_attr( self::OPT ); ?>[notify_news]" value="1" <?php checked( $o['notify_news'] ); ?>> Send an email for each new newsletter sign-up</label></td></tr>
					<tr><th scope="row">Auto-reply</th><td><label><input type="checkbox" name="<?php echo esc_attr( self::OPT ); ?>[autoreply]" value="1" <?php checked( $o['autoreply'] ); ?>> Send people a “we’ve received your message” email</label></td></tr>
					<tr><th scope="row"><label for="tokf-rl">Limit per visitor</label></th><td><input id="tokf-rl" type="number" min="1" max="50" name="<?php echo esc_attr( self::OPT ); ?>[rate_limit]" value="<?php echo esc_attr( $o['rate_limit'] ); ?>"> messages per hour</td></tr>
				</table>
				<?php submit_button(); ?>
			</form>
			<p>Emails not arriving? Install <strong>WP Mail SMTP</strong> and connect it to info@tokconsult.com.ng. Every message is saved under Forms → Messages either way.</p>
		</div>
		<?php
	}
}

register_activation_hook( __FILE__, array( 'TOKF', 'activate' ) );
TOKF::init();
