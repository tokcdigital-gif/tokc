<?php
/**
 * Plugin Name:       TOKCONSULT SEO
 * Description:       Search and AI visibility for tokconsult.com.ng: page titles and descriptions, social sharing previews, structured data (business, services, FAQs, articles), an llms.txt file and a few sitemap fixes. No setup needed. Do not run alongside Yoast, Rank Math or another SEO plugin.
 * Version:           1.0.0
 * Author:            TOKCONSULT
 * Requires at least: 6.0
 * Requires PHP:      7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class TOKSEO {

	private static $data = null;

	public static function init() {
		add_filter( 'pre_get_document_title', array( __CLASS__, 'title' ), 99 );
		add_action( 'wp_head', array( __CLASS__, 'head' ), 2 );
		add_filter( 'wp_robots', array( __CLASS__, 'robots' ) );
		add_filter( 'wp_sitemaps_add_provider', array( __CLASS__, 'sitemap_providers' ), 10, 2 );
		add_filter( 'wp_sitemaps_posts_query_args', array( __CLASS__, 'sitemap_exclude' ), 10, 2 );
		add_action( 'init', array( __CLASS__, 'llms_txt' ), 0 );
		add_action( 'after_setup_theme', array( __CLASS__, 'remove_theme_description' ), 99 );
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register_setting' ) );
	}

	/* ---------- data ---------- */

	public static function data() {
		if ( null === self::$data ) {
			$json       = file_get_contents( plugin_dir_path( __FILE__ ) . 'assets/seo-data.json' ); // phpcs:ignore
			self::$data = json_decode( $json, true );
		}
		return self::$data;
	}

	/** Which page entry applies to the current request, or null. */
	private static function key() {
		if ( is_front_page() ) {
			return '__home';
		}
		if ( is_page() ) {
			$p = get_queried_object();
			return $p ? $p->post_name : null;
		}
		return null;
	}

	private static function entry() {
		$k = self::key();
		$d = self::data();
		return ( $k && isset( $d['pages'][ $k ] ) ) ? $d['pages'][ $k ] : null;
	}

	private static function post_desc( $post ) {
		$t = has_excerpt( $post ) ? get_the_excerpt( $post ) : wp_strip_all_tags( strip_shortcodes( $post->post_content ) );
		$t = trim( preg_replace( '/\s+/', ' ', $t ) );
		if ( function_exists( 'mb_strlen' ) && mb_strlen( $t ) > 155 ) {
			$t = rtrim( mb_substr( $t, 0, 152 ), " ,.;:" ) . '…';
		}
		return $t;
	}

	/* ---------- title ---------- */

	public static function title( $title ) {
		$e = self::entry();
		if ( $e ) {
			return $e['title'];
		}
		if ( is_singular( 'post' ) ) {
			return single_post_title( '', false ) . ' | TOKCONSULT Blog';
		}
		if ( is_category() ) {
			return single_cat_title( '', false ) . ' articles | TOKCONSULT Blog';
		}
		return $title;
	}

	/* ---------- head tags ---------- */

	public static function head() {
		if ( is_admin() || is_feed() ) {
			return;
		}
		$d     = self::data();
		$e     = self::entry();
		$url   = self::current_url();
		$title = wp_get_document_title();
		$desc  = '';
		$image = $d['org']['default_image'];
		$type  = 'website';

		if ( $e ) {
			$desc  = $e['desc'];
			$image = $e['image'] ? $e['image'] : $image;
		} elseif ( is_singular( 'post' ) ) {
			$p     = get_queried_object();
			$desc  = self::post_desc( $p );
			$thumb = get_the_post_thumbnail_url( $p, 'large' );
			$image = $thumb ? $thumb : $image;
			$type  = 'article';
		}

		$out = "\n<!-- TOKCONSULT SEO -->\n";
		if ( $desc ) {
			$out .= '<meta name="description" content="' . esc_attr( $desc ) . '">' . "\n";
		}
		$out .= '<meta property="og:site_name" content="TOKCONSULT">' . "\n";
		$out .= '<meta property="og:locale" content="en_NG">' . "\n";
		$out .= '<meta property="og:type" content="' . esc_attr( $type ) . '">' . "\n";
		$out .= '<meta property="og:title" content="' . esc_attr( $title ) . '">' . "\n";
		if ( $desc ) {
			$out .= '<meta property="og:description" content="' . esc_attr( $desc ) . '">' . "\n";
		}
		$out .= '<meta property="og:url" content="' . esc_url( $url ) . '">' . "\n";
		$out .= '<meta property="og:image" content="' . esc_url( $image ) . '">' . "\n";
		$out .= '<meta name="twitter:card" content="summary_large_image">' . "\n";
		$out .= '<meta name="twitter:site" content="@tokconsult">' . "\n";

		$code = trim( (string) get_option( 'tokseo_gsc', '' ) );
		if ( $code ) {
			$out .= '<meta name="google-site-verification" content="' . esc_attr( $code ) . '">' . "\n";
		}

		$graph = self::schema( $url, $title, $desc, $image );
		if ( $graph ) {
			$out .= '<script type="application/ld+json">' . wp_json_encode( array( '@context' => 'https://schema.org', '@graph' => $graph ), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . "</script>\n";
		}
		echo $out . "<!-- /TOKCONSULT SEO -->\n"; // phpcs:ignore -- built from escaped parts
	}

	private static function current_url() {
		if ( is_front_page() ) {
			return home_url( '/' );
		}
		if ( is_singular() ) {
			return get_permalink( get_queried_object() );
		}
		if ( is_category() ) {
			return get_category_link( get_queried_object_id() );
		}
		return home_url( add_query_arg( array() ) );
	}

	/* ---------- structured data ---------- */

	private static function org_node() {
		$o = self::data()['org'];
		return array(
			'@type'       => array( 'ProfessionalService', 'Organization' ),
			'@id'         => $o['url'] . '#organization',
			'name'        => $o['name'],
			'url'         => $o['url'],
			'logo'        => plugins_url( 'assets/logo.png', __FILE__ ),
			'image'       => $o['default_image'],
			'description' => $o['description'],
			'email'       => $o['email'],
			'telephone'   => $o['telephone'],
			'priceRange'  => $o['priceRange'],
			'address'     => array(
				'@type'           => 'PostalAddress',
				'addressLocality' => $o['city'],
				'addressCountry'  => $o['country'],
			),
			'areaServed'  => array( '@type' => 'Country', 'name' => $o['areaServed'] ),
			'sameAs'      => $o['sameAs'],
		);
	}

	private static function schema( $url, $title, $desc, $image ) {
		$d     = self::data();
		$org   = $d['org']['url'] . '#organization';
		$k     = self::key();
		$graph = array();

		if ( '__home' === $k ) {
			$graph[] = self::org_node();
			$graph[] = array(
				'@type'     => 'WebSite',
				'@id'       => $d['org']['url'] . '#website',
				'url'       => $d['org']['url'],
				'name'      => 'TOKCONSULT',
				'publisher' => array( '@id' => $org ),
				'inLanguage' => 'en-NG',
			);
			return $graph;
		}

		if ( 'contact-us' === $k || 'about' === $k ) {
			$graph[] = self::org_node();
		}

		if ( $k && isset( $d['services'][ $k ] ) ) {
			$s       = $d['services'][ $k ];
			$graph[] = array(
				'@type'       => 'Service',
				'name'        => $s['name'],
				'description' => $s['desc'],
				'url'         => $url,
				'provider'    => array( '@id' => $org, '@type' => 'Organization', 'name' => 'TOKCONSULT' ),
				'areaServed'  => array( '@type' => 'Country', 'name' => 'Nigeria' ),
				'offers'      => array(
					'@type'         => 'AggregateOffer',
					'priceCurrency' => 'NGN',
					'lowPrice'      => $s['low'],
					'highPrice'     => $s['high'],
				),
			);
		}

		if ( $k && ! empty( $d['faqs'][ $k ] ) ) {
			$qs = array();
			foreach ( $d['faqs'][ $k ] as $qa ) {
				$qs[] = array(
					'@type'          => 'Question',
					'name'           => $qa[0],
					'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $qa[1] ),
				);
			}
			$graph[] = array( '@type' => 'FAQPage', 'url' => $url, 'mainEntity' => $qs );
		}

		if ( is_singular( 'post' ) ) {
			$p       = get_queried_object();
			$graph[] = array(
				'@type'            => 'BlogPosting',
				'headline'         => get_the_title( $p ),
				'description'      => $desc,
				'image'            => $image,
				'url'              => $url,
				'datePublished'    => get_the_date( 'c', $p ),
				'dateModified'     => get_the_modified_date( 'c', $p ),
				'author'           => array( '@type' => 'Organization', 'name' => 'TOKCONSULT', 'url' => $d['org']['url'] ),
				'publisher'        => array( '@id' => $org, '@type' => 'Organization', 'name' => 'TOKCONSULT', 'logo' => plugins_url( 'assets/logo.png', __FILE__ ) ),
				'mainEntityOfPage' => $url,
				'inLanguage'       => 'en-NG',
			);
		}
		return $graph;
	}

	/* ---------- robots / sitemap ---------- */

	public static function robots( $robots ) {
		$k = self::key();
		if ( $k && in_array( $k, self::data()['noindex'], true ) ) {
			$robots['noindex'] = true;
			$robots['follow']  = true;
		}
		return $robots;
	}

	/** Remove the users sitemap: it publishes admin usernames and has no search value. */
	public static function sitemap_providers( $provider, $name ) {
		return 'users' === $name ? false : $provider;
	}

	public static function sitemap_exclude( $args, $post_type ) {
		if ( 'page' === $post_type ) {
			$ids = array();
			foreach ( self::data()['noindex'] as $slug ) {
				$p = get_page_by_path( $slug );
				if ( $p ) {
					$ids[] = $p->ID;
				}
			}
			if ( $ids ) {
				$args['post__not_in'] = array_merge( isset( $args['post__not_in'] ) ? (array) $args['post__not_in'] : array(), $ids );
			}
		}
		return $args;
	}

	/** Hello Elementor prints its own description tag; remove it so there is only one. */
	public static function remove_theme_description() {
		remove_action( 'wp_head', 'hello_elementor_add_description_meta_tag' );
	}

	/* ---------- llms.txt ---------- */

	public static function llms_txt() {
		$path = isset( $_SERVER['REQUEST_URI'] ) ? wp_parse_url( wp_unslash( $_SERVER['REQUEST_URI'] ), PHP_URL_PATH ) : ''; // phpcs:ignore
		if ( '/llms.txt' !== untrailingslashit( (string) $path ) ) {
			return;
		}
		header( 'Content-Type: text/plain; charset=utf-8' );
		header( 'X-Robots-Tag: noindex' );
		readfile( plugin_dir_path( __FILE__ ) . 'assets/llms.txt' ); // phpcs:ignore
		exit;
	}

	/* ---------- tiny settings page: Search Console code ---------- */

	public static function register_setting() {
		register_setting( 'tokseo', 'tokseo_gsc', array( 'type' => 'string', 'sanitize_callback' => array( __CLASS__, 'clean_code' ) ) );
	}

	public static function clean_code( $v ) {
		$v = trim( (string) $v );
		if ( preg_match( '/content="([^"]+)"/', $v, $m ) ) {
			$v = $m[1]; // accept the whole <meta> tag pasted from Google
		}
		return sanitize_text_field( $v );
	}

	public static function menu() {
		add_options_page( 'TOKCONSULT SEO', 'TOKCONSULT SEO', 'manage_options', 'tokseo', array( __CLASS__, 'page' ) );
	}

	public static function page() {
		?>
		<div class="wrap">
			<h1>TOKCONSULT SEO</h1>
			<p>Titles, descriptions, structured data and <a href="<?php echo esc_url( home_url( '/llms.txt' ) ); ?>" target="_blank">llms.txt</a> are already active. The only setting is your Google Search Console verification code.</p>
			<form method="post" action="options.php">
				<?php settings_fields( 'tokseo' ); ?>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="tokseo_gsc">Google verification</label></th>
						<td>
							<input id="tokseo_gsc" name="tokseo_gsc" type="text" class="regular-text" value="<?php echo esc_attr( get_option( 'tokseo_gsc', '' ) ); ?>">
							<p class="description">In Search Console choose “URL prefix”, then “HTML tag”, and paste the whole tag or just the code here.</p>
						</td>
					</tr>
				</table>
				<?php submit_button(); ?>
			</form>
		</div>
		<?php
	}
}

TOKSEO::init();
