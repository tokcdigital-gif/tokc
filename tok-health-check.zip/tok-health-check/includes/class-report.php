<?php
/**
 * Scoring, bands, the fallback report and validation of the AI report.
 * Pure PHP: no WordPress calls except apply_filters (via config) and the escaping helpers.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class TOKHC_Report {

	/**
	 * Score a list of answers ('y' / 'n') in question order.
	 *
	 * @return array{total:int,max:int,areas:array<string,array{label:string,score:int,max:int}>}
	 */
	public static function score( array $answers ) {
		$questions = tokhc_questions();
		$areas     = array();
		foreach ( tokhc_areas() as $key => $label ) {
			$areas[ $key ] = array( 'label' => $label, 'score' => 0, 'max' => 0 );
		}
		$total = 0;
		foreach ( $questions as $i => $q ) {
			$area = $q['area'];
			if ( ! isset( $areas[ $area ] ) ) {
				continue;
			}
			$areas[ $area ]['max']++;
			if ( isset( $answers[ $i ] ) && 'y' === $answers[ $i ] ) {
				$areas[ $area ]['score']++;
				$total++;
			}
		}
		return array( 'total' => $total, 'max' => count( $questions ), 'areas' => $areas );
	}

	public static function band( $total ) {
		$bands = tokhc_bands();
		foreach ( $bands as $b ) {
			if ( $total >= $b['min'] && $total <= $b['max'] ) {
				return $b;
			}
		}
		return end( $bands );
	}

	/**
	 * Area keys from weakest to strongest (by share of points, ties keep question order).
	 */
	public static function weakest_areas( array $areas ) {
		$keys  = array_keys( $areas );
		$order = array_flip( $keys );
		usort(
			$keys,
			function ( $a, $b ) use ( $areas, $order ) {
				$ra = $areas[ $a ]['max'] ? $areas[ $a ]['score'] / $areas[ $a ]['max'] : 1;
				$rb = $areas[ $b ]['max'] ? $areas[ $b ]['score'] / $areas[ $b ]['max'] : 1;
				if ( $ra === $rb ) {
					return $order[ $a ] - $order[ $b ];
				}
				return ( $ra < $rb ) ? -1 : 1;
			}
		);
		return $keys;
	}

	/**
	 * Report built from fixed text. Same shape as the AI report.
	 */
	public static function fallback( array $scored ) {
		$band     = self::band( $scored['total'] );
		$weak     = array_slice( self::weakest_areas( $scored['areas'] ), 0, 2 );
		$fallback = tokhc_area_fallback();
		$areas    = tokhc_areas();

		$priorities = array();
		foreach ( $weak as $key ) {
			$priorities[] = array(
				'area'       => $key,
				'insight'    => $fallback[ $key ]['insight'],
				'first_step' => $fallback[ $key ]['first_step'],
			);
		}

		// Low and mid scores start with the band's audit; a high score with one weak area gets that area's product.
		$service_id = $band['next'];
		if ( 'high' === $band['key'] && $scored['areas'][ $weak[0] ]['score'] < $scored['areas'][ $weak[0] ]['max'] ) {
			$service_id = $fallback[ $weak[0] ]['service'];
		}

		if ( $scored['total'] >= $scored['max'] ) {
			$reason = 'Your foundation is strong. Ongoing support helps you keep it that way as you grow.';
		} else {
			$reason = sprintf(
				'Your weakest area is %s, and this is the most direct way to start fixing it.',
				strtolower( $areas[ $weak[0] ] )
			);
		}

		return array(
			'headline'       => $band['title'],
			'summary'        => $band['message'],
			'priorities'     => $priorities,
			'recommendation' => array(
				'service_id' => $service_id,
				'reason'     => $reason,
			),
			'source'         => 'fallback',
		);
	}

	/**
	 * Validate and clean the AI's report. Returns null if anything required is wrong,
	 * so the caller can fall back.
	 */
	public static function validate_ai( $data ) {
		if ( ! is_array( $data ) ) {
			return null;
		}
		$areas    = tokhc_areas();
		$services = tokhc_services();

		$headline = self::clean_text( $data['headline'] ?? '', 120 );
		$summary  = self::clean_text( $data['summary'] ?? '', 600 );
		if ( '' === $headline || '' === $summary ) {
			return null;
		}

		if ( empty( $data['priorities'] ) || ! is_array( $data['priorities'] ) ) {
			return null;
		}
		$priorities = array();
		foreach ( array_slice( $data['priorities'], 0, 2 ) as $p ) {
			if ( ! is_array( $p ) ) {
				return null;
			}
			$area       = is_string( $p['area'] ?? null ) ? strtolower( trim( $p['area'] ) ) : '';
			$insight    = self::clean_text( $p['insight'] ?? '', 400 );
			$first_step = self::clean_text( $p['first_step'] ?? '', 300 );
			if ( ! isset( $areas[ $area ] ) || '' === $insight || '' === $first_step ) {
				return null;
			}
			$priorities[] = array( 'area' => $area, 'insight' => $insight, 'first_step' => $first_step );
		}
		if ( count( $priorities ) < 1 ) {
			return null;
		}

		$rec        = $data['recommendation'] ?? null;
		$service_id = is_array( $rec ) && is_string( $rec['service_id'] ?? null ) ? trim( $rec['service_id'] ) : '';
		$reason     = is_array( $rec ) ? self::clean_text( $rec['reason'] ?? '', 400 ) : '';
		if ( ! isset( $services[ $service_id ] ) || '' === $reason ) {
			return null;
		}

		return array(
			'headline'       => $headline,
			'summary'        => $summary,
			'priorities'     => $priorities,
			'recommendation' => array( 'service_id' => $service_id, 'reason' => $reason ),
			'source'         => 'ai',
		);
	}

	/**
	 * Plain text only: strip tags and links, collapse whitespace, cap length.
	 */
	public static function clean_text( $value, $max ) {
		if ( ! is_string( $value ) ) {
			return '';
		}
		$value = wp_strip_all_tags( $value );
		$value = preg_replace( '#https?://\S+#i', '', $value );
		$value = trim( preg_replace( '/\s+/u', ' ', $value ) );
		if ( function_exists( 'mb_strlen' ) && mb_strlen( $value ) > $max ) {
			$value = rtrim( mb_substr( $value, 0, $max - 1 ) ) . '…';
		}
		return $value;
	}

	/**
	 * Public payload for the browser and the emails.
	 */
	public static function public_payload( array $scored, array $report ) {
		$band     = self::band( $scored['total'] );
		$services = tokhc_services();
		$areas    = tokhc_areas();
		$sid      = $report['recommendation']['service_id'];
		$svc      = $services[ $sid ];

		$priorities = array();
		foreach ( $report['priorities'] as $p ) {
			$priorities[] = array(
				'area'       => $areas[ $p['area'] ],
				'insight'    => $p['insight'],
				'first_step' => $p['first_step'],
			);
		}

		$area_list = array();
		foreach ( $scored['areas'] as $key => $a ) {
			$area_list[] = array( 'key' => $key, 'label' => $a['label'], 'score' => $a['score'], 'max' => $a['max'] );
		}

		return array(
			'score'          => $scored['total'],
			'max'            => $scored['max'],
			'band'           => array( 'key' => $band['key'], 'title' => $band['title'] ),
			'areas'          => $area_list,
			'headline'       => $report['headline'],
			'summary'        => $report['summary'],
			'priorities'     => $priorities,
			'recommendation' => array(
				'name'   => $svc['name'],
				'price'  => $svc['price'],
				'reason' => $report['recommendation']['reason'],
				'url'    => self::service_url( $svc['url'] ),
			),
			'source'         => $report['source'],
		);
	}

	public static function service_url( $url ) {
		if ( 0 === strpos( $url, '/' ) && function_exists( 'home_url' ) ) {
			return home_url( $url );
		}
		return $url;
	}
}
