<?php
/**
 * Calls the Claude Messages API from the server. The API key never reaches the browser.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class TOKHC_AI {

	const ENDPOINT = 'https://api.anthropic.com/v1/messages';

	/**
	 * The key: a TOKHC_ANTHROPIC_KEY constant in wp-config.php wins over the settings field.
	 */
	public static function api_key() {
		if ( defined( 'TOKHC_ANTHROPIC_KEY' ) && TOKHC_ANTHROPIC_KEY ) {
			return TOKHC_ANTHROPIC_KEY;
		}
		return (string) TOKHC_Plugin::opt( 'api_key' );
	}

	public static function is_ready() {
		return TOKHC_Plugin::opt( 'ai_enabled' ) && '' !== self::api_key();
	}

	/**
	 * Build the user message: the submission as JSON. Only first name and business name
	 * are sent; phone and email never leave your server.
	 */
	public static function build_input( array $sub, array $scored ) {
		$questions = tokhc_questions();
		$answers   = array();
		foreach ( $questions as $i => $q ) {
			$answers[ $q['area'] ][] = array(
				'question' => $q['text'],
				'answer'   => ( isset( $sub['answers'][ $i ] ) && 'y' === $sub['answers'][ $i ] ) ? 'yes' : 'no',
			);
		}
		$area_scores = array();
		foreach ( $scored['areas'] as $key => $a ) {
			$area_scores[ $key ] = $a['score'] . '/' . $a['max'];
		}
		$first = trim( strtok( $sub['name'], ' ' ) );

		return wp_json_encode(
			array(
				'first_name'      => $first,
				'business_name'   => $sub['business'],
				'total_score'     => $scored['total'] . '/' . $scored['max'],
				'area_scores'     => $area_scores,
				'answers'         => $answers,
				'challenge_note'  => '' !== $sub['challenge'] ? $sub['challenge'] : null,
			),
			JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE
		);
	}

	/**
	 * @return array|WP_Error Validated report array, or an error to trigger the fallback.
	 */
	public static function generate( array $sub, array $scored ) {
		if ( ! self::is_ready() ) {
			return new WP_Error( 'tokhc_ai_off', 'AI is switched off or has no API key.' );
		}

		$body = array(
			'model'       => TOKHC_Plugin::opt( 'model' ),
			'max_tokens'  => 1500,
			'system'      => tokhc_system_prompt(),
			'messages'    => array(
				array( 'role' => 'user', 'content' => self::build_input( $sub, $scored ) ),
			),
		);

		$response = wp_remote_post(
			self::ENDPOINT,
			array(
				'timeout' => (int) apply_filters( 'tokhc_ai_timeout', 25 ),
				'headers' => array(
					'x-api-key'         => self::api_key(),
					'anthropic-version' => '2023-06-01',
					'content-type'      => 'application/json',
				),
				'body'    => wp_json_encode( $body ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}
		$code = (int) wp_remote_retrieve_response_code( $response );
		$json = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( 200 !== $code || ! is_array( $json ) ) {
			$msg = is_array( $json ) && isset( $json['error']['message'] ) ? $json['error']['message'] : 'HTTP ' . $code;
			return new WP_Error( 'tokhc_ai_http', $msg );
		}

		$text = '';
		foreach ( (array) ( $json['content'] ?? array() ) as $block ) {
			if ( isset( $block['type'], $block['text'] ) && 'text' === $block['type'] ) {
				$text .= $block['text'];
			}
		}

		$report = TOKHC_Report::validate_ai( self::extract_json( $text ) );
		if ( null === $report ) {
			return new WP_Error( 'tokhc_ai_invalid', 'The AI reply did not match the expected format.' );
		}
		return $report;
	}

	/**
	 * Pull the JSON object out of the reply, tolerating code fences or stray text.
	 */
	public static function extract_json( $text ) {
		$start = strpos( $text, '{' );
		$end   = strrpos( $text, '}' );
		if ( false === $start || false === $end || $end <= $start ) {
			return null;
		}
		$data = json_decode( substr( $text, $start, $end - $start + 1 ), true );
		return is_array( $data ) ? $data : null;
	}
}
