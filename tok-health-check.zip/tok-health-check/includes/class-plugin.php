<?php
/**
 * Shortcode, assets, the submit endpoint, storage and the webhook.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class TOKHC_Plugin {

	const OPTION = 'tokhc_settings';

	public static function defaults() {
		return array(
			'ai_enabled'   => 1,
			'api_key'      => '',
			'model'        => 'claude-sonnet-5-5',
			'admin_email'  => 'info@tokconsult.com.ng',
			'from_name'    => 'TOKCONSULT',
			'from_email'   => '',
			'email_user'   => 1,
			'webhook_url'  => '',
			'privacy_url'  => '/privacy-policy/',
			'whatsapp_url' => 'https://wa.link/k3be0i',
			'rate_limit'   => 5,
			'load_fonts'   => 1,
		);
	}

	public static function opt( $key ) {
		$all = wp_parse_args( (array) get_option( self::OPTION, array() ), self::defaults() );
		return $all[ $key ] ?? null;
	}

	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'tokhc_submissions';
	}

	public static function init() {
		add_shortcode( 'tok_health_check', array( __CLASS__, 'shortcode' ) );
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	public static function activate() {
		global $wpdb;
		$table   = self::table();
		$charset = $wpdb->get_charset_collate();
		$sql     = "CREATE TABLE {$table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			created_at datetime NOT NULL,
			name varchar(120) NOT NULL,
			business varchar(160) NOT NULL,
			phone varchar(40) NOT NULL,
			email varchar(160) NOT NULL,
			answers varchar(64) NOT NULL,
			score tinyint(3) unsigned NOT NULL,
			area_scores text NOT NULL,
			challenge text NULL,
			report longtext NOT NULL,
			source varchar(10) NOT NULL,
			consent tinyint(1) NOT NULL DEFAULT 0,
			ip_hash char(64) NOT NULL,
			PRIMARY KEY  (id),
			KEY created_at (created_at),
			KEY email (email)
		) {$charset};";
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql );

		if ( false === get_option( self::OPTION ) ) {
			add_option( self::OPTION, self::defaults() );
		}
	}

	/* ---------- Front end ---------- */

	public static function shortcode() {
		if ( self::opt( 'load_fonts' ) ) {
			wp_enqueue_style( 'tokhc-fonts', 'https://fonts.googleapis.com/css2?family=Sora:wght@600;700;800&family=DM+Sans:opsz,wght@9..40,400;9..40,500;9..40,700&display=swap', array(), null );
		}
		wp_enqueue_style( 'tokhc', TOKHC_URL . 'assets/health-check.css', array(), TOKHC_VER );
		wp_enqueue_script( 'tokhc', TOKHC_URL . 'assets/health-check.js', array(), TOKHC_VER, true );

		$questions = array();
		foreach ( tokhc_questions() as $q ) {
			$questions[] = array( 'area' => $q['area'], 'text' => $q['text'] );
		}
		$privacy = self::opt( 'privacy_url' );

		wp_localize_script(
			'tokhc',
			'TOKHC',
			array(
				'endpoint'  => esc_url_raw( rest_url( 'tokhc/v1/submit' ) ),
				'questions' => $questions,
				'areas'     => tokhc_areas(),
				'privacy'   => esc_url_raw( TOKHC_Report::service_url( $privacy ) ),
				'whatsapp'  => esc_url_raw( self::opt( 'whatsapp_url' ) ),
				'emailUser' => (bool) self::opt( 'email_user' ),
			)
		);

		return '<div class="tokhc" id="tokhc-app" aria-live="polite"><noscript><p>Please turn on JavaScript to take the Health Check, or <a href="' . esc_url( self::opt( 'whatsapp_url' ) ) . '">chat with us on WhatsApp</a>.</p></noscript></div>';
	}

	/* ---------- Submit endpoint ---------- */

	public static function routes() {
		register_rest_route(
			'tokhc/v1',
			'/submit',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'submit' ),
				'permission_callback' => '__return_true',
			)
		);
	}

	private static function client_ip_hash() {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		return hash( 'sha256', $ip . wp_salt( 'nonce' ) );
	}

	/**
	 * Clean and check the submission. Returns [clean array, null] or [null, WP_Error].
	 */
	public static function validate_input( array $in ) {
		$count   = count( tokhc_questions() );
		$name    = sanitize_text_field( (string) ( $in['name'] ?? '' ) );
		$biz     = sanitize_text_field( (string) ( $in['business'] ?? '' ) );
		$phone   = preg_replace( '/[^0-9+ ]/', '', (string) ( $in['phone'] ?? '' ) );
		$email   = sanitize_email( (string) ( $in['email'] ?? '' ) );
		$note    = sanitize_textarea_field( (string) ( $in['challenge'] ?? '' ) );
		$consent = ! empty( $in['consent'] );
		$answers = is_array( $in['answers'] ?? null ) ? array_values( $in['answers'] ) : array();

		if ( '' === $name || '' === $biz || strlen( preg_replace( '/\D/', '', $phone ) ) < 10 || ! is_email( $email ) ) {
			return array( null, new WP_Error( 'tokhc_fields', 'Please fill in your name, business, WhatsApp number and a valid email.', array( 'status' => 400 ) ) );
		}
		if ( ! $consent ) {
			return array( null, new WP_Error( 'tokhc_consent', 'Please tick the consent box so we can process your answers.', array( 'status' => 400 ) ) );
		}
		if ( count( $answers ) !== $count ) {
			return array( null, new WP_Error( 'tokhc_answers', 'Please answer all the questions.', array( 'status' => 400 ) ) );
		}
		foreach ( $answers as $a ) {
			if ( 'y' !== $a && 'n' !== $a ) {
				return array( null, new WP_Error( 'tokhc_answers', 'Please answer all the questions.', array( 'status' => 400 ) ) );
			}
		}

		return array(
			array(
				'name'      => mb_substr( $name, 0, 120 ),
				'business'  => mb_substr( $biz, 0, 160 ),
				'phone'     => mb_substr( trim( $phone ), 0, 40 ),
				'email'     => mb_substr( $email, 0, 160 ),
				'challenge' => mb_substr( trim( $note ), 0, 400 ),
				'answers'   => $answers,
				'consent'   => true,
			),
			null,
		);
	}

	public static function submit( WP_REST_Request $request ) {
		$in = (array) $request->get_json_params();

		// Bots: a hidden field humans never fill, and a minimum time on the form.
		if ( ! empty( $in['website'] ) || (int) ( $in['elapsed'] ?? 0 ) < 8000 ) {
			return new WP_Error( 'tokhc_spam', 'Something went wrong. Please try again.', array( 'status' => 400 ) );
		}

		list( $sub, $err ) = self::validate_input( $in );
		if ( $err ) {
			return $err;
		}

		$ip_hash = self::client_ip_hash();
		$rl_key  = 'tokhc_rl_' . substr( $ip_hash, 0, 32 );
		$hits    = (int) get_transient( $rl_key );
		$limit   = max( 1, (int) self::opt( 'rate_limit' ) );
		if ( $hits >= $limit ) {
			return new WP_Error( 'tokhc_rate', 'You have taken the Health Check several times in the last hour. Please try again later or chat with us on WhatsApp.', array( 'status' => 429 ) );
		}
		set_transient( $rl_key, $hits + 1, HOUR_IN_SECONDS );

		$scored = TOKHC_Report::score( $sub['answers'] );
		$report = TOKHC_AI::generate( $sub, $scored );
		if ( is_wp_error( $report ) ) {
			if ( TOKHC_AI::is_ready() ) {
				error_log( '[TOKCONSULT Health Check] AI fallback: ' . $report->get_error_message() );
			}
			$report = TOKHC_Report::fallback( $scored );
		}

		$payload = TOKHC_Report::public_payload( $scored, $report );
		$id      = self::save( $sub, $scored, $payload, $ip_hash );

		TOKHC_Mailer::send_all( $sub, $payload, $id );
		self::webhook( $sub, $payload, $id );

		$payload['emailed'] = (bool) self::opt( 'email_user' );
		return rest_ensure_response( $payload );
	}

	private static function save( array $sub, array $scored, array $payload, $ip_hash ) {
		global $wpdb;
		$area_scores = array();
		foreach ( $scored['areas'] as $k => $a ) {
			$area_scores[ $k ] = $a['score'];
		}
		$wpdb->insert(
			self::table(),
			array(
				'created_at'  => current_time( 'mysql' ),
				'name'        => $sub['name'],
				'business'    => $sub['business'],
				'phone'       => $sub['phone'],
				'email'       => $sub['email'],
				'answers'     => implode( '', $sub['answers'] ),
				'score'       => $scored['total'],
				'area_scores' => wp_json_encode( $area_scores ),
				'challenge'   => $sub['challenge'],
				'report'      => wp_json_encode( $payload ),
				'source'      => $payload['source'],
				'consent'     => 1,
				'ip_hash'     => $ip_hash,
			),
			array( '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%d', '%s' )
		);
		return (int) $wpdb->insert_id;
	}

	/**
	 * Optional: send each lead to Google Sheets (Apps Script), Make, Zapier or a CRM.
	 */
	private static function webhook( array $sub, array $p, $id ) {
		$url = self::opt( 'webhook_url' );
		if ( ! $url || ! wp_http_validate_url( $url ) ) {
			return;
		}
		$areas = array();
		foreach ( $p['areas'] as $a ) {
			$areas[ $a['label'] ] = $a['score'];
		}
		wp_remote_post(
			$url,
			array(
				'timeout'  => 5,
				'blocking' => false,
				'headers'  => array( 'content-type' => 'application/json' ),
				'body'     => wp_json_encode(
					array(
						'id'          => $id,
						'date'        => current_time( 'c' ),
						'name'        => $sub['name'],
						'business'    => $sub['business'],
						'whatsapp'    => $sub['phone'],
						'email'       => $sub['email'],
						'score'       => $p['score'],
						'band'        => $p['band']['title'],
						'areas'       => $areas,
						'recommended' => $p['recommendation']['name'],
						'challenge'   => $sub['challenge'],
						'source'      => $p['source'],
					)
				),
			)
		);
	}
}
