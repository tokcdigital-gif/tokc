<?php
/**
 * Admin screens: submissions list, CSV export, settings and an AI connection test.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class TOKHC_Admin {

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
		add_action( 'admin_post_tokhc_export', array( __CLASS__, 'export_csv' ) );
		add_action( 'admin_post_tokhc_test', array( __CLASS__, 'test_ai' ) );
	}

	public static function menu() {
		add_menu_page( 'Health Check', 'Health Check', 'manage_options', 'tokhc', array( __CLASS__, 'page_submissions' ), 'dashicons-chart-bar', 58 );
		add_submenu_page( 'tokhc', 'Submissions', 'Submissions', 'manage_options', 'tokhc', array( __CLASS__, 'page_submissions' ) );
		add_submenu_page( 'tokhc', 'Health Check settings', 'Settings', 'manage_options', 'tokhc-settings', array( __CLASS__, 'page_settings' ) );
	}

	/* ---------- Settings ---------- */

	public static function register_settings() {
		register_setting(
			'tokhc',
			TOKHC_Plugin::OPTION,
			array( 'sanitize_callback' => array( __CLASS__, 'sanitize' ) )
		);
	}

	public static function sanitize( $in ) {
		$old = wp_parse_args( (array) get_option( TOKHC_Plugin::OPTION, array() ), TOKHC_Plugin::defaults() );
		$in  = (array) $in;
		$out = array(
			'ai_enabled'   => empty( $in['ai_enabled'] ) ? 0 : 1,
			'model'        => sanitize_text_field( $in['model'] ?? $old['model'] ),
			'admin_email'  => sanitize_email( $in['admin_email'] ?? '' ),
			'from_name'    => sanitize_text_field( $in['from_name'] ?? '' ),
			'from_email'   => sanitize_email( $in['from_email'] ?? '' ),
			'email_user'   => empty( $in['email_user'] ) ? 0 : 1,
			'webhook_url'  => esc_url_raw( $in['webhook_url'] ?? '' ),
			'privacy_url'  => sanitize_text_field( $in['privacy_url'] ?? '' ),
			'whatsapp_url' => esc_url_raw( $in['whatsapp_url'] ?? '' ),
			'rate_limit'   => max( 1, min( 50, (int) ( $in['rate_limit'] ?? 5 ) ) ),
			'load_fonts'   => empty( $in['load_fonts'] ) ? 0 : 1,
		);
		// Keep the saved key when the field is left blank.
		$new_key        = trim( (string) ( $in['api_key'] ?? '' ) );
		$out['api_key'] = '' !== $new_key ? sanitize_text_field( $new_key ) : $old['api_key'];
		if ( ! empty( $in['clear_key'] ) ) {
			$out['api_key'] = '';
		}
		return $out;
	}

	public static function page_settings() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$o          = wp_parse_args( (array) get_option( TOKHC_Plugin::OPTION, array() ), TOKHC_Plugin::defaults() );
		$name       = TOKHC_Plugin::OPTION;
		$key_in_cfg = defined( 'TOKHC_ANTHROPIC_KEY' ) && TOKHC_ANTHROPIC_KEY;
		$test       = get_transient( 'tokhc_test_result' );
		delete_transient( 'tokhc_test_result' );
		?>
		<div class="wrap">
			<h1>Health Check settings</h1>
			<p>Add the Health Check to any page with the shortcode <code>[tok_health_check]</code>. Questions, prices and links are edited in <code>includes/config.php</code>.</p>
			<?php if ( $test ) : ?>
				<div class="notice notice-<?php echo 'ok' === $test['status'] ? 'success' : 'error'; ?>"><p><?php echo esc_html( $test['message'] ); ?></p></div>
			<?php endif; ?>
			<form method="post" action="options.php">
				<?php settings_fields( 'tokhc' ); ?>
				<h2>AI report</h2>
				<table class="form-table" role="presentation">
					<tr><th scope="row">Use AI for the report</th><td><label><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[ai_enabled]" value="1" <?php checked( $o['ai_enabled'] ); ?>> On</label><p class="description">When off, or if the AI is unavailable, visitors get a report written from fixed text.</p></td></tr>
					<tr><th scope="row"><label for="tokhc-key">Claude API key</label></th><td>
						<?php if ( $key_in_cfg ) : ?>
							<p><strong>Set in wp-config.php.</strong> (Recommended.)</p>
						<?php else : ?>
							<input id="tokhc-key" type="password" class="regular-text" autocomplete="off" name="<?php echo esc_attr( $name ); ?>[api_key]" value="" placeholder="<?php echo $o['api_key'] ? 'Saved. Leave blank to keep it.' : 'sk-ant-…'; ?>">
							<?php if ( $o['api_key'] ) : ?><label style="margin-left:8px"><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[clear_key]" value="1"> Remove saved key</label><?php endif; ?>
							<p class="description">Safer: add <code>define( 'TOKHC_ANTHROPIC_KEY', 'your-key' );</code> to wp-config.php instead of saving it here.</p>
						<?php endif; ?>
					</td></tr>
					<tr><th scope="row"><label for="tokhc-model">Model</label></th><td><input id="tokhc-model" type="text" class="regular-text" name="<?php echo esc_attr( $name ); ?>[model]" value="<?php echo esc_attr( $o['model'] ); ?>"><p class="description">Default <code>claude-sonnet-5-5</code>.</p></td></tr>
				</table>
				<h2>Emails and leads</h2>
				<table class="form-table" role="presentation">
					<tr><th scope="row">Email the report to the visitor</th><td><label><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[email_user]" value="1" <?php checked( $o['email_user'] ); ?>> On</label></td></tr>
					<tr><th scope="row"><label for="tokhc-admin">Send lead alerts to</label></th><td><input id="tokhc-admin" type="email" class="regular-text" name="<?php echo esc_attr( $name ); ?>[admin_email]" value="<?php echo esc_attr( $o['admin_email'] ); ?>"></td></tr>
					<tr><th scope="row"><label for="tokhc-fromn">From name</label></th><td><input id="tokhc-fromn" type="text" class="regular-text" name="<?php echo esc_attr( $name ); ?>[from_name]" value="<?php echo esc_attr( $o['from_name'] ); ?>"></td></tr>
					<tr><th scope="row"><label for="tokhc-frome">From email</label></th><td><input id="tokhc-frome" type="email" class="regular-text" name="<?php echo esc_attr( $name ); ?>[from_email]" value="<?php echo esc_attr( $o['from_email'] ); ?>"><p class="description">Use an address on your own domain, e.g. info@tokconsult.com.ng. Leave blank to use your SMTP plugin's setting.</p></td></tr>
					<tr><th scope="row"><label for="tokhc-hook">Webhook URL (optional)</label></th><td><input id="tokhc-hook" type="url" class="regular-text" name="<?php echo esc_attr( $name ); ?>[webhook_url]" value="<?php echo esc_attr( $o['webhook_url'] ); ?>"><p class="description">Each lead is also sent here as JSON: a Google Sheets Apps Script, Make, Zapier or your CRM.</p></td></tr>
				</table>
				<h2>Page</h2>
				<table class="form-table" role="presentation">
					<tr><th scope="row"><label for="tokhc-priv">Privacy Policy link</label></th><td><input id="tokhc-priv" type="text" class="regular-text" name="<?php echo esc_attr( $name ); ?>[privacy_url]" value="<?php echo esc_attr( $o['privacy_url'] ); ?>"></td></tr>
					<tr><th scope="row"><label for="tokhc-wa">WhatsApp link</label></th><td><input id="tokhc-wa" type="url" class="regular-text" name="<?php echo esc_attr( $name ); ?>[whatsapp_url]" value="<?php echo esc_attr( $o['whatsapp_url'] ); ?>"></td></tr>
					<tr><th scope="row"><label for="tokhc-rl">Attempts per hour, per visitor</label></th><td><input id="tokhc-rl" type="number" min="1" max="50" name="<?php echo esc_attr( $name ); ?>[rate_limit]" value="<?php echo esc_attr( $o['rate_limit'] ); ?>"></td></tr>
					<tr><th scope="row">Load Sora and DM Sans fonts</th><td><label><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[load_fonts]" value="1" <?php checked( $o['load_fonts'] ); ?>> On</label><p class="description">Turn off if your theme already loads them.</p></td></tr>
				</table>
				<?php submit_button(); ?>
			</form>
			<hr>
			<h2>Test the AI</h2>
			<p>Sends one sample submission to Claude and shows whether a valid report came back. No email is sent and nothing is saved.</p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="tokhc_test">
				<?php wp_nonce_field( 'tokhc_test' ); ?>
				<?php submit_button( 'Run test', 'secondary', 'submit', false ); ?>
			</form>
		</div>
		<?php
	}

	public static function test_ai() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'tokhc_test' );

		$answers = array( 'y', 'n', 'n', 'y', 'y', 'n', 'n', 'n', 'n', 'y', 'n', 'y', 'y', 'n', 'y' );
		$sub     = array( 'name' => 'Test User', 'business' => 'Sample Foods Ltd', 'challenge' => 'Sales are up and down every month.', 'answers' => $answers );
		$scored  = TOKHC_Report::score( $answers );

		if ( ! TOKHC_AI::is_ready() ) {
			$result = array( 'status' => 'error', 'message' => 'AI is switched off or no API key is set.' );
		} else {
			$start  = microtime( true );
			$report = TOKHC_AI::generate( $sub, $scored );
			$secs   = round( microtime( true ) - $start, 1 );
			if ( is_wp_error( $report ) ) {
				$result = array( 'status' => 'error', 'message' => 'AI test failed: ' . $report->get_error_message() );
			} else {
				$result = array( 'status' => 'ok', 'message' => sprintf( 'AI test passed in %ss. Headline: "%s". Recommended: %s.', $secs, $report['headline'], $report['recommendation']['service_id'] ) );
			}
		}
		set_transient( 'tokhc_test_result', $result, 60 );
		wp_safe_redirect( admin_url( 'admin.php?page=tokhc-settings' ) );
		exit;
	}

	/* ---------- Submissions ---------- */

	public static function page_submissions() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		global $wpdb;
		$table = TOKHC_Plugin::table();
		$view  = isset( $_GET['view'] ) ? absint( $_GET['view'] ) : 0;

		if ( $view ) {
			$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $view ) );
			echo '<div class="wrap"><h1>Submission #' . (int) $view . '</h1><p><a href="' . esc_url( admin_url( 'admin.php?page=tokhc' ) ) . '">← All submissions</a></p>';
			if ( $row ) {
				$p = json_decode( $row->report, true );
				echo '<table class="widefat striped" style="max-width:860px"><tbody>';
				$fields = array(
					'Date'      => $row->created_at,
					'Name'      => $row->name,
					'Business'  => $row->business,
					'WhatsApp'  => $row->phone,
					'Email'     => $row->email,
					'Score'     => $row->score . '/15 · ' . ( $p['band']['title'] ?? '' ),
					'Challenge' => $row->challenge ? $row->challenge : '—',
					'Headline'  => $p['headline'] ?? '',
					'Summary'   => $p['summary'] ?? '',
				);
				foreach ( (array) ( $p['priorities'] ?? array() ) as $i => $x ) {
					$fields[ 'Priority ' . ( $i + 1 ) . ' · ' . $x['area'] ] = $x['insight'] . ' This week: ' . $x['first_step'];
				}
				$fields['Recommended'] = ( $p['recommendation']['name'] ?? '' ) . ' — ' . ( $p['recommendation']['reason'] ?? '' );
				$fields['Source']      = 'ai' === $row->source ? 'AI' : 'Fixed text';
				foreach ( $fields as $k => $v ) {
					echo '<tr><th style="width:200px">' . esc_html( $k ) . '</th><td>' . esc_html( $v ) . '</td></tr>';
				}
				echo '</tbody></table>';
			}
			echo '</div>';
			return;
		}

		$rows = $wpdb->get_results( "SELECT id, created_at, name, business, phone, email, score, source FROM {$table} ORDER BY id DESC LIMIT 200" );
		?>
		<div class="wrap">
			<h1 class="wp-heading-inline">Health Check submissions</h1>
			<a class="page-title-action" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=tokhc_export' ), 'tokhc_export' ) ); ?>">Export CSV</a>
			<p>Latest 200. Export for the full list.</p>
			<table class="widefat striped">
				<thead><tr><th>Date</th><th>Name</th><th>Business</th><th>WhatsApp</th><th>Email</th><th>Score</th><th>Report</th><th></th></tr></thead>
				<tbody>
				<?php if ( ! $rows ) : ?>
					<tr><td colspan="8">No submissions yet.</td></tr>
				<?php endif; ?>
				<?php foreach ( (array) $rows as $r ) : ?>
					<tr>
						<td><?php echo esc_html( $r->created_at ); ?></td>
						<td><?php echo esc_html( $r->name ); ?></td>
						<td><?php echo esc_html( $r->business ); ?></td>
						<td><a href="<?php echo esc_url( 'https://wa.me/' . preg_replace( '/\D/', '', $r->phone ) ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $r->phone ); ?></a></td>
						<td><a href="mailto:<?php echo esc_attr( $r->email ); ?>"><?php echo esc_html( $r->email ); ?></a></td>
						<td><strong><?php echo (int) $r->score; ?>/15</strong></td>
						<td><?php echo 'ai' === $r->source ? 'AI' : 'Fixed'; ?></td>
						<td><a href="<?php echo esc_url( admin_url( 'admin.php?page=tokhc&view=' . (int) $r->id ) ); ?>">View</a></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	public static function export_csv() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'tokhc_export' );
		global $wpdb;
		$table = TOKHC_Plugin::table();
		$rows  = $wpdb->get_results( "SELECT * FROM {$table} ORDER BY id DESC", ARRAY_A );

		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=health-check-' . gmdate( 'Y-m-d' ) . '.csv' );
		$out = fopen( 'php://output', 'w' );
		fwrite( $out, "\xEF\xBB\xBF" );
		fputcsv( $out, array( 'ID', 'Date', 'Name', 'Business', 'WhatsApp', 'Email', 'Score', 'Money', 'Market', 'Operations', 'Growth', 'Risk', 'Recommended', 'Challenge', 'Source' ) );
		foreach ( (array) $rows as $r ) {
			$a = json_decode( $r['area_scores'], true );
			$p = json_decode( $r['report'], true );
			fputcsv(
				$out,
				array_map(
					array( __CLASS__, 'csv_safe' ),
					array(
						$r['id'], $r['created_at'], $r['name'], $r['business'], $r['phone'], $r['email'], $r['score'],
						$a['money'] ?? '', $a['market'] ?? '', $a['operations'] ?? '', $a['growth'] ?? '', $a['risk'] ?? '',
						$p['recommendation']['name'] ?? '', $r['challenge'], $r['source'],
					)
				)
			);
		}
		fclose( $out );
		exit;
	}

	/**
	 * Stop spreadsheet formula injection from visitor-typed text.
	 */
	public static function csv_safe( $v ) {
		$v = (string) $v;
		if ( '' !== $v && in_array( $v[0], array( '=', '+', '-', '@' ), true ) && ! is_numeric( $v ) ) {
			$v = "'" . $v;
		}
		return $v;
	}
}
