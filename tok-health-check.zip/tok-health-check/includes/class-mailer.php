<?php
/**
 * Emails: the report to the visitor and a lead alert to TOKCONSULT.
 * For reliable delivery, install an SMTP plugin (e.g. WP Mail SMTP, FluentSMTP).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class TOKHC_Mailer {

	public static function send_all( array $sub, array $payload, $id ) {
		if ( TOKHC_Plugin::opt( 'email_user' ) ) {
			self::send_user( $sub, $payload );
		}
		self::send_admin( $sub, $payload, $id );
	}

	private static function headers() {
		$from_name  = TOKHC_Plugin::opt( 'from_name' );
		$from_email = TOKHC_Plugin::opt( 'from_email' );
		$h          = array( 'Content-Type: text/html; charset=UTF-8' );
		if ( $from_email && is_email( $from_email ) ) {
			$h[] = sprintf( 'From: %s <%s>', $from_name, $from_email );
		}
		$reply = TOKHC_Plugin::opt( 'admin_email' );
		if ( $reply && is_email( $reply ) ) {
			$h[] = 'Reply-To: ' . $reply;
		}
		return $h;
	}

	public static function send_user( array $sub, array $p ) {
		$first   = trim( strtok( $sub['name'], ' ' ) );
		$subject = sprintf( 'Your Business Health Check result: %d/%d', $p['score'], $p['max'] );
		wp_mail( $sub['email'], $subject, self::user_html( $first, $sub['business'], $p ), self::headers() );
	}

	public static function user_html( $first, $business, array $p ) {
		$navy  = '#121B32';
		$coral = '#D4463A';
		$grey  = '#4A5266';

		$areas = '';
		foreach ( $p['areas'] as $a ) {
			$pct    = $a['max'] ? round( $a['score'] / $a['max'] * 100 ) : 0;
			$areas .= '<tr><td style="padding:6px 0;font-weight:700;width:120px">' . esc_html( $a['label'] ) . '</td>'
				. '<td style="padding:6px 0"><div style="background:#E8EBF1;border-radius:6px;height:10px"><div style="background:' . $navy . ';border-radius:6px;height:10px;width:' . (int) $pct . '%"></div></div></td>'
				. '<td style="padding:6px 0 6px 12px;text-align:right;font-weight:700;width:40px">' . (int) $a['score'] . '/' . (int) $a['max'] . '</td></tr>';
		}

		$prio = '';
		foreach ( $p['priorities'] as $i => $x ) {
			$prio .= '<div style="margin:0 0 18px"><p style="margin:0 0 4px;font-size:12px;letter-spacing:.12em;text-transform:uppercase;color:' . $coral . ';font-weight:700">Priority ' . ( $i + 1 ) . ' · ' . esc_html( $x['area'] ) . '</p>'
				. '<p style="margin:0 0 6px">' . esc_html( $x['insight'] ) . '</p>'
				. '<p style="margin:0"><strong>This week:</strong> ' . esc_html( $x['first_step'] ) . '</p></div>';
		}

		$wa = TOKHC_Plugin::opt( 'whatsapp_url' );

		ob_start();
		?>
<div style="background:#F5F6F8;padding:32px 12px;font-family:Arial,Helvetica,sans-serif;color:<?php echo $navy; ?>;font-size:16px;line-height:1.55">
<div style="max-width:600px;margin:0 auto;background:#FFFFFF;border-radius:16px;overflow:hidden">
<div style="background:<?php echo $navy; ?>;color:#FFFFFF;padding:28px 32px">
<p style="margin:0 0 6px;font-size:12px;letter-spacing:.14em;text-transform:uppercase;color:#C9CFDC">TOKCONSULT · Business Health Check</p>
<p style="margin:0;font-size:40px;font-weight:700;line-height:1"><?php echo (int) $p['score']; ?><span style="font-size:18px;color:#C9CFDC"> / <?php echo (int) $p['max']; ?></span></p>
<p style="margin:8px 0 0;font-size:18px;font-weight:700"><?php echo esc_html( $p['band']['title'] ); ?></p>
</div>
<div style="padding:28px 32px">
<p style="margin:0 0 16px">Hi <?php echo esc_html( $first ); ?>, here is the Health Check result for <?php echo esc_html( $business ); ?>.</p>
<h2 style="margin:0 0 8px;font-size:20px;color:<?php echo $navy; ?>"><?php echo esc_html( $p['headline'] ); ?></h2>
<p style="margin:0 0 24px;color:<?php echo $grey; ?>"><?php echo esc_html( $p['summary'] ); ?></p>
<table role="presentation" style="width:100%;border-collapse:collapse;margin:0 0 28px;font-size:14px"><?php echo $areas; // already escaped ?></table>
<?php echo $prio; // already escaped ?>
<div style="background:#FDF1EF;border-radius:12px;padding:20px;margin:8px 0 24px">
<p style="margin:0 0 4px;font-size:12px;letter-spacing:.12em;text-transform:uppercase;color:<?php echo $coral; ?>;font-weight:700">Recommended next step</p>
<p style="margin:0 0 6px;font-weight:700"><?php echo esc_html( $p['recommendation']['name'] ); ?> · <?php echo esc_html( $p['recommendation']['price'] ); ?></p>
<p style="margin:0 0 14px"><?php echo esc_html( $p['recommendation']['reason'] ); ?></p>
<a href="<?php echo esc_url( $p['recommendation']['url'] ); ?>" style="display:inline-block;background:<?php echo $coral; ?>;color:#FFFFFF;text-decoration:none;font-weight:700;padding:12px 20px;border-radius:8px">See <?php echo esc_html( $p['recommendation']['name'] ); ?></a>
</div>
<?php if ( $wa ) : ?>
<p style="margin:0 0 8px">Questions? <a href="<?php echo esc_url( $wa ); ?>" style="color:<?php echo $coral; ?>;font-weight:700">Chat with us on WhatsApp</a>.</p>
<?php endif; ?>
<p style="margin:16px 0 0;font-size:12px;color:<?php echo $grey; ?>">This report is general business guidance based on your answers. It is not legal, tax or financial advice.</p>
</div>
</div>
</div>
		<?php
		return ob_get_clean();
	}

	public static function send_admin( array $sub, array $p, $id ) {
		$to = TOKHC_Plugin::opt( 'admin_email' );
		if ( ! $to || ! is_email( $to ) ) {
			return;
		}
		$subject = sprintf( 'New Health Check lead: %s (%d/%d)', $sub['business'], $p['score'], $p['max'] );
		$wa      = 'https://wa.me/' . preg_replace( '/\D/', '', $sub['phone'] );
		$rows    = array(
			'Name'           => $sub['name'],
			'Business'       => $sub['business'],
			'WhatsApp'       => $sub['phone'],
			'Email'          => $sub['email'],
			'Score'          => $p['score'] . '/' . $p['max'] . ' · ' . $p['band']['title'],
			'Weakest areas'  => implode( ', ', wp_list_pluck( $p['priorities'], 'area' ) ),
			'Recommended'    => $p['recommendation']['name'],
			'Challenge note' => $sub['challenge'] ? $sub['challenge'] : '—',
			'Report source'  => 'ai' === $p['source'] ? 'AI' : 'Fixed text (AI off or unavailable)',
		);
		$html = '<div style="font-family:Arial,sans-serif;font-size:15px;color:#121B32"><p>New Business Health Check submission (#' . (int) $id . ').</p><table style="border-collapse:collapse">';
		foreach ( $rows as $k => $v ) {
			$html .= '<tr><td style="padding:4px 16px 4px 0;font-weight:700;vertical-align:top">' . esc_html( $k ) . '</td><td style="padding:4px 0">' . esc_html( $v ) . '</td></tr>';
		}
		$html .= '</table><p><a href="' . esc_url( $wa ) . '">Open WhatsApp chat</a> · <a href="' . esc_url( admin_url( 'admin.php?page=tokhc' ) ) . '">View all submissions</a></p></div>';

		wp_mail( $to, $subject, $html, self::headers() );
	}
}
