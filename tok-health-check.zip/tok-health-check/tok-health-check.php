<?php
/**
 * Plugin Name:       TOKCONSULT Business Health Check
 * Description:       15-question Business Health Check with an instant score and an AI-written report (Claude). Add it to any page with the shortcode [tok_health_check].
 * Version:           1.0.1
 * Author:            TOKCONSULT
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Text Domain:       tok-health-check
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'TOKHC_VER', '1.0.1' );
define( 'TOKHC_DIR', plugin_dir_path( __FILE__ ) );
define( 'TOKHC_URL', plugin_dir_url( __FILE__ ) );

require_once TOKHC_DIR . 'includes/config.php';
require_once TOKHC_DIR . 'includes/class-report.php';
require_once TOKHC_DIR . 'includes/class-ai.php';
require_once TOKHC_DIR . 'includes/class-mailer.php';
require_once TOKHC_DIR . 'includes/class-plugin.php';
require_once TOKHC_DIR . 'includes/class-admin.php';

register_activation_hook( __FILE__, array( 'TOKHC_Plugin', 'activate' ) );

TOKHC_Plugin::init();
TOKHC_Admin::init();
