/* TOKCONSULT Business Health Check — front end. No dependencies. */
(function () {
  'use strict';

  var cfg = window.TOKHC;
  var root = document.getElementById('tokhc-app');
  if (!cfg || !root) return;

  var areaKeys = Object.keys(cfg.areas);
  var steps = ['about'].concat(areaKeys).concat(['finish']);
  var state = {
    step: 0,
    name: '', business: '', phone: '', email: '',
    answers: cfg.questions.map(function () { return null; }),
    challenge: '', consent: false, website: '',
    started: Date.now(),
    result: null, error: '', loading: false
  };

  /* ---------- tiny DOM helper: text is always set with textContent ---------- */
  function h(tag, attrs, kids) {
    var el = document.createElement(tag);
    attrs = attrs || {};
    Object.keys(attrs).forEach(function (k) {
      var v = attrs[k];
      if (v === null || v === undefined || v === false) return;
      if (k === 'class') el.className = v;
      else if (k === 'text') el.textContent = v;
      else if (k.indexOf('on') === 0) el.addEventListener(k.slice(2), v);
      else if (k === 'style') el.setAttribute('style', v);
      else el.setAttribute(k, v === true ? '' : v);
    });
    (kids || []).forEach(function (c) {
      if (c === null || c === undefined || c === false) return;
      el.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
    });
    return el;
  }

  // focusSel: element to focus after drawing. stay: true keeps the scroll position (e.g. after a Yes/No click).
  function render(focusSel, stay) {
    root.innerHTML = '';
    var view;
    if (state.loading) view = viewLoading();
    else if (state.result) view = viewResult();
    else view = viewStep();
    root.appendChild(view);
    var target = root.querySelector(focusSel || '[data-focus]');
    if (target) target.focus({ preventScroll: true });
    if (stay) return;
    var top = root.getBoundingClientRect().top + window.pageYOffset - 100;
    if (window.pageYOffset > top) window.scrollTo({ top: top, behavior: 'smooth' });
  }

  /* ---------- progress ---------- */
  function progress() {
    var pct = Math.round((state.step / (steps.length - 1)) * 100);
    return h('div', { class: 'tokhc-progress' }, [
      h('div', { class: 'tokhc-progress-row' }, [
        h('span', { text: 'Step ' + (state.step + 1) + ' of ' + steps.length }),
        h('span', { text: answeredCount() + ' of ' + cfg.questions.length + ' answered' })
      ]),
      h('div', { class: 'tokhc-bar', role: 'progressbar', 'aria-valuemin': '0', 'aria-valuemax': '100', 'aria-valuenow': String(pct), 'aria-label': 'Progress' }, [
        h('div', { class: 'tokhc-bar-fill', style: 'width:' + pct + '%' })
      ])
    ]);
  }

  function answeredCount() {
    return state.answers.filter(function (a) { return a !== null; }).length;
  }

  function errorBox() {
    return state.error ? h('p', { class: 'tokhc-error', role: 'alert', text: state.error }) : null;
  }

  /* ---------- steps ---------- */
  function viewStep() {
    var key = steps[state.step];
    var body;
    if (key === 'about') body = stepAbout();
    else if (key === 'finish') body = stepFinish();
    else body = stepArea(key);
    return h('div', { class: 'tokhc-card' }, [progress(), body]);
  }

  function field(label, type, prop, extra) {
    var id = 'tokhc-' + prop;
    var input = h('input', Object.assign({
      id: id, type: type, value: state[prop],
      oninput: function (e) { state[prop] = e.target.value; }
    }, extra || {}));
    return h('div', { class: 'tokhc-field' }, [h('label', { for: id, text: label }), input]);
  }

  function stepAbout() {
    return h('form', { class: 'tokhc-step', novalidate: true, onsubmit: function (e) { e.preventDefault(); next(); } }, [
      h('h2', { class: 'tokhc-h', text: 'First, about you', tabindex: '-1', 'data-focus': true }),
      h('p', { class: 'tokhc-muted', text: '3 minutes. 15 yes-or-no questions. Your result appears straight away.' }),
      h('div', { class: 'tokhc-grid' }, [
        field('Your name', 'text', 'name', { autocomplete: 'name', required: true }),
        field('Business name', 'text', 'business', { autocomplete: 'organization', required: true }),
        field('WhatsApp number', 'tel', 'phone', { autocomplete: 'tel', placeholder: '+234', required: true }),
        field('Email', 'email', 'email', { autocomplete: 'email', required: true })
      ]),
      errorBox(),
      h('div', { class: 'tokhc-actions' }, [
        h('span'),
        h('button', { type: 'submit', class: 'tokhc-btn tokhc-btn-p', text: 'Start' })
      ])
    ]);
  }

  function stepArea(key) {
    var items = [];
    cfg.questions.forEach(function (q, i) {
      if (q.area !== key) return;
      var qid = 'tokhc-q' + i;
      items.push(h('div', { class: 'tokhc-q' }, [
        h('p', { id: qid, class: 'tokhc-q-text', text: q.text }),
        h('div', { class: 'tokhc-yn', role: 'group', 'aria-labelledby': qid }, [
          ynButton(i, 'y', 'Yes'), ynButton(i, 'n', 'No')
        ])
      ]));
    });
    var idx = areaKeys.indexOf(key) + 1;
    return h('div', { class: 'tokhc-step' }, [
      h('p', { class: 'tokhc-label', text: 'Area ' + idx + ' of ' + areaKeys.length }),
      h('h2', { class: 'tokhc-h', text: cfg.areas[key], tabindex: '-1', 'data-focus': true }),
      h('div', { class: 'tokhc-qs' }, items),
      errorBox(),
      h('div', { class: 'tokhc-actions' }, [
        h('button', { type: 'button', class: 'tokhc-btn tokhc-btn-g', text: 'Back', onclick: back }),
        h('button', { type: 'button', class: 'tokhc-btn tokhc-btn-p', text: 'Next', onclick: next })
      ])
    ]);
  }

  function ynButton(i, val, label) {
    var on = state.answers[i] === val;
    return h('button', {
      type: 'button', class: 'tokhc-ynb' + (on ? ' is-on' : ''), 'aria-pressed': on ? 'true' : 'false', text: label,
      onclick: function () {
        state.answers[i] = val;
        state.error = '';
        render('#tokhc-q' + i + ' + .tokhc-yn .is-on', true);
      }
    });
  }

  function stepFinish() {
    var privacyLink = h('a', { href: cfg.privacy, target: '_blank', rel: 'noopener', text: 'Privacy Policy' });
    return h('form', { class: 'tokhc-step', novalidate: true, onsubmit: function (e) { e.preventDefault(); submit(); } }, [
      h('h2', { class: 'tokhc-h', text: 'Almost done', tabindex: '-1', 'data-focus': true }),
      h('div', { class: 'tokhc-field' }, [
        h('label', { for: 'tokhc-challenge', text: 'What’s your biggest business challenge right now? (optional)' }),
        h('textarea', { id: 'tokhc-challenge', rows: '3', maxlength: '400', oninput: function (e) { state.challenge = e.target.value; } }, [state.challenge])
      ]),
      h('div', { class: 'tokhc-hp', 'aria-hidden': 'true' }, [
        h('label', { for: 'tokhc-website', text: 'Website' }),
        h('input', { id: 'tokhc-website', type: 'text', tabindex: '-1', autocomplete: 'off', oninput: function (e) { state.website = e.target.value; } })
      ]),
      h('label', { class: 'tokhc-consent' }, [
        h('input', { type: 'checkbox', checked: state.consent, onchange: function (e) {
          state.consent = e.target.checked;
          if (state.consent && state.error) {
            state.error = '';
            var box = root.querySelector('.tokhc-error');
            if (box) box.parentNode.removeChild(box);
          }
        } }),
        h('span', {}, [
          'I agree that TOKCONSULT may process my answers, including with an AI tool, to produce my report and contact me about it, as set out in the ',
          privacyLink, '.'
        ])
      ]),
      errorBox(),
      h('div', { class: 'tokhc-actions' }, [
        h('button', { type: 'button', class: 'tokhc-btn tokhc-btn-g', text: 'Back', onclick: back }),
        h('button', { type: 'submit', class: 'tokhc-btn tokhc-btn-p', text: 'See my result' })
      ])
    ]);
  }

  /* ---------- navigation ---------- */
  function validStep() {
    var key = steps[state.step];
    if (key === 'about') {
      if (!state.name.trim() || !state.business.trim()) return 'Please add your name and business name.';
      if (state.phone.replace(/\D/g, '').length < 10) return 'Please add a WhatsApp number we can reach you on.';
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(state.email.trim())) return 'Please add a valid email address.';
      return '';
    }
    if (key === 'finish') return state.consent ? '' : 'Please tick the consent box to see your result.';
    var missing = cfg.questions.some(function (q, i) { return q.area === key && state.answers[i] === null; });
    return missing ? 'Please answer all three questions.' : '';
  }

  function next() {
    var err = validStep();
    if (err) { state.error = err; render('.tokhc-error'); return; }
    state.error = '';
    state.step = Math.min(state.step + 1, steps.length - 1);
    render();
  }

  function back() {
    state.error = '';
    state.step = Math.max(state.step - 1, 0);
    render();
  }

  /* ---------- submit ---------- */
  function submit() {
    var err = validStep();
    if (err) { state.error = err; render('.tokhc-error'); return; }
    state.error = '';
    state.loading = true;
    render();

    fetch(cfg.endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: state.name, business: state.business, phone: state.phone, email: state.email,
        answers: state.answers, challenge: state.challenge, consent: state.consent,
        website: state.website, elapsed: Date.now() - state.started
      })
    })
      .then(function (r) {
        return r.json().then(function (data) { return { ok: r.ok, data: data }; });
      })
      .then(function (res) {
        state.loading = false;
        if (!res.ok) {
          state.error = (res.data && res.data.message) || 'Something went wrong. Please try again.';
          render('.tokhc-error');
          return;
        }
        state.result = res.data;
        render();
      })
      .catch(function () {
        state.loading = false;
        state.error = 'We couldn’t reach the server. Check your connection and try again.';
        render('.tokhc-error');
      });
  }

  /* ---------- loading ---------- */
  function viewLoading() {
    var msg = h('p', { class: 'tokhc-muted', text: 'Scoring your answers…' });
    var lines = ['Scoring your answers…', 'Finding your two biggest gaps…', 'Writing your report…'];
    var n = 0;
    var timer = setInterval(function () {
      if (!state.loading || !msg.isConnected) { clearInterval(timer); return; }
      n = Math.min(n + 1, lines.length - 1);
      msg.textContent = lines[n];
    }, 3000);
    return h('div', { class: 'tokhc-card tokhc-loading', role: 'status' }, [
      h('div', { class: 'tokhc-spinner', 'aria-hidden': 'true' }),
      h('h2', { class: 'tokhc-h', text: 'Preparing your report' }),
      msg
    ]);
  }

  /* ---------- result ---------- */
  function viewResult() {
    var r = state.result;
    var areas = r.areas.map(function (a) {
      var pct = a.max ? Math.round((a.score / a.max) * 100) : 0;
      return h('div', { class: 'tokhc-area' }, [
        h('span', { class: 'tokhc-area-name', text: a.label }),
        h('div', { class: 'tokhc-bar' }, [h('div', { class: 'tokhc-bar-fill tokhc-bar-navy', style: 'width:' + pct + '%' })]),
        h('span', { class: 'tokhc-area-score', text: a.score + '/' + a.max })
      ]);
    });

    var prios = r.priorities.map(function (p, i) {
      return h('div', { class: 'tokhc-prio' }, [
        h('p', { class: 'tokhc-label tokhc-coral', text: 'Priority ' + (i + 1) + ' · ' + p.area }),
        h('p', { text: p.insight }),
        h('p', {}, [h('strong', { text: 'This week: ' }), p.first_step])
      ]);
    });

    var rec = r.recommendation;

    return h('div', { class: 'tokhc-result' }, [
      h('div', { class: 'tokhc-card tokhc-head' }, [
        h('div', { class: 'tokhc-score', 'aria-label': 'Score ' + r.score + ' out of ' + r.max }, [
          h('span', { class: 'tokhc-score-n', text: String(r.score) }),
          h('span', { class: 'tokhc-score-of', text: 'out of ' + r.max })
        ]),
        h('div', { class: 'tokhc-head-text' }, [
          r.band.title !== r.headline ? h('p', { class: 'tokhc-label tokhc-coral', text: r.band.title }) : null,
          h('h2', { class: 'tokhc-h', text: r.headline, tabindex: '-1', 'data-focus': true }),
          h('p', { class: 'tokhc-muted', text: r.summary })
        ])
      ]),
      h('div', { class: 'tokhc-card' }, [h('h3', { class: 'tokhc-h3', text: 'Score by area' })].concat(areas)),
      h('div', { class: 'tokhc-card' }, [h('h3', { class: 'tokhc-h3', text: 'Where to start' })].concat(prios)),
      h('div', { class: 'tokhc-card tokhc-rec' }, [
        h('p', { class: 'tokhc-label tokhc-coral', text: 'Recommended next step' }),
        h('h3', { class: 'tokhc-h3', text: rec.name + ' · ' + rec.price }),
        h('p', { text: rec.reason }),
        h('div', { class: 'tokhc-actions tokhc-actions-start' }, [
          h('a', { class: 'tokhc-btn tokhc-btn-p', href: rec.url, text: 'See ' + rec.name }),
          cfg.whatsapp ? h('a', { class: 'tokhc-btn tokhc-btn-g', href: cfg.whatsapp, target: '_blank', rel: 'noopener', text: 'Chat on WhatsApp' }) : null
        ])
      ]),
      h('p', { class: 'tokhc-note', text: (r.emailed ? 'We’ve emailed a copy to ' + state.email + '. ' : '') + 'This report is general business guidance based on your answers. It is not legal, tax or financial advice.' })
    ]);
  }

  render();
})();
