# TOKCONSULT Business Health Check — setup guide

A WordPress plugin that runs the free Business Health Check:

1. The visitor answers 15 yes-or-no questions across five steps (Money, Market, Operations, Growth, Risk), plus an optional "biggest challenge" note and a consent tick box.
2. Your server scores the answers with fixed rules, so the score is always the same for the same answers.
3. Claude writes a short personal report: a headline, a summary, the two priority areas with one action each for this week, and one recommended TOKCONSULT service.
4. The visitor sees the report on screen and gets a copy by email. You get a lead alert with their WhatsApp link.
5. Every submission is saved in WordPress (Health Check → Submissions, with CSV export) and can also be sent to a Google Sheet or CRM.

If the AI is switched off, has no key, is slow (over 25 seconds) or replies in the wrong format, the visitor still gets a complete report written from fixed text. They never see an empty screen.

---

## 1. Install

1. WordPress admin → **Plugins → Add New → Upload Plugin** → choose `tok-health-check.zip` → **Install** → **Activate**.
2. A **Health Check** menu appears in the admin sidebar.

## 2. Get a Claude API key

1. Go to **console.anthropic.com**, sign in, and add a payment method under **Billing**. Add a small amount of credit to start.
2. Under **API keys**, create a key named "TOKCONSULT website". Copy it; it starts with `sk-ant-`.
3. Set a monthly spend limit in the Console, as a safety net.

**Cost:** each report uses roughly 2,000 input and 500 output tokens. On the default model (`claude-sonnet-5-5`, $2 / $10 per million tokens), that is under one US cent per report, so about $8–9 for 1,000 reports. `claude-haiku-5-5` is cheaper still.

## 3. Add the key (safest way)

Ask your host or developer to add this line to `wp-config.php`, above the line that says "That's all, stop editing":

```php
define( 'TOKHC_ANTHROPIC_KEY', 'sk-ant-your-key-here' );
```

If you can't edit `wp-config.php`, paste the key in **Health Check → Settings** instead. It works the same way, but the key is then stored in the database.

## 4. Settings

Go to **Health Check → Settings**:

- **Use AI for the report:** on.
- **Model:** leave as `claude-sonnet-5-5`.
- **Send lead alerts to:** info@tokconsult.com.ng.
- **From email:** an address on your domain, e.g. info@tokconsult.com.ng.
- **Privacy Policy link:** your policy page, e.g. `/privacy-policy/`.
- **WhatsApp link:** `https://wa.link/k3be0i`.

Then click **Run test** at the bottom. You should see "AI test passed…". If it fails, the message says why (usually a wrong key or no credit).

## 5. Make sure emails arrive

WordPress's built-in email often lands in spam. Install **WP Mail SMTP** or **FluentSMTP** and connect it to the mailbox for info@tokconsult.com.ng (or a service like Brevo). Then take the Health Check yourself and check your inbox.

## 6. Put it on the page

1. Create or edit your **Business Health Check** page.
2. Build the navy header section with your page builder (headline: *How healthy is your business, really?*).
3. Under it, add a **Shortcode** block or widget containing:

```
[tok_health_check]
```

4. Publish, then do a full test on your phone.

## 7. Update your Privacy Policy

The form asks for consent to process answers "including with an AI tool". Your Privacy Policy should say, in line with the NDPA 2023:

- What is collected: name, business name, WhatsApp number, email, Health Check answers and the optional challenge note.
- Why: to produce the report, email it, and follow up about TOKCONSULT services.
- That answers, first name and business name are sent to Anthropic (Claude) to write the report. **Phone numbers and email addresses are not sent to the AI.**
- How long you keep submissions, and how people can ask for access or deletion.

## 8. Edit questions, prices and links

Everything is in **`includes/config.php`**:

- **`tokhc_questions()`:** the 15 questions. Replace them with the Business Audit Questionnaire. Keep three per area, and word each one so that "Yes" is the healthy answer.
- **`tokhc_bands()`:** the three result bands and their messages.
- **`tokhc_services()`:** the only services the report can recommend, with prices and page links. **Update this when the rate card changes**, and change each `url` to match your real page addresses.
- **`tokhc_area_fallback()`:** the fixed advice used when the AI is unavailable.
- **`tokhc_system_prompt()`:** the AI's locked instructions.

Edit the file in **Plugins → Plugin File Editor**, or over FTP. Back it up first.

## 9. Optional: send leads to a Google Sheet

1. Create a Google Sheet. Go to **Extensions → Apps Script** and paste:

```javascript
function doPost(e) {
  var d = JSON.parse(e.postData.contents);
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName('Leads') || ss.insertSheet('Leads');
  if (sh.getLastRow() === 0) {
    sh.appendRow(['Date','Name','Business','WhatsApp','Email','Score','Band','Money','Market','Operations','Growth','Risk','Recommended','Challenge','Report']);
  }
  var a = d.areas || {};
  sh.appendRow([d.date, d.name, d.business, d.whatsapp, d.email, d.score, d.band,
    a.Money, a.Market, a.Operations, a.Growth, a.Risk, d.recommended, d.challenge, d.source]);
  return ContentService.createTextOutput('ok');
}
```

2. **Deploy → New deployment → Web app**, with "Execute as: Me" and "Who has access: Anyone". Copy the web app URL.
3. Paste it into **Health Check → Settings → Webhook URL**.

The same webhook works with Make, Zapier or most CRMs.

## How the AI is kept safe

- The API key stays on your server and is never in the page.
- The AI can only recommend services from your list, picked by id. The plugin checks every reply and inserts the real name, price and link itself, so the AI cannot invent a product, price, discount or link.
- Replies are stripped of HTML and links before display, and anything that doesn't match the expected shape is replaced with the fixed-text report.
- The instructions forbid legal, tax and financial advice and promises of results, and tell the AI to ignore any instructions typed into the challenge box.
- Spam protection: a hidden honeypot field, a minimum time on the form, and a limit of 5 attempts per hour per visitor (adjustable).

## Troubleshooting

- **"Something went wrong" on submit:** a security plugin (Wordfence, iThemes, etc.) may be blocking the WordPress REST API for logged-out visitors. Allow the route `/wp-json/tokhc/v1/submit`.
- **Reports always say "Fixed" in Submissions:** run the test in Settings. Check the key, your Console credit, and that your host allows outgoing connections to api.anthropic.com. Errors are also written to the PHP error log.
- **The form looks unstyled or text is hard to read:** clear your caching or optimisation plugin's cache. The form's styles are scoped to `.tokhc` and set their own colours, so the theme shouldn't override them.
- **Page builder preview is blank:** shortcodes often only run on the live page. Check the published page.
