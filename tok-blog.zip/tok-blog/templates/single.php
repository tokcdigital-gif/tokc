<?php
/**
 * Blog post template supplied by the TOKCONSULT Blog plugin.
 * Uses the theme's own header (menu) and footer, with the TOKCONSULT article design in between.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
get_header();
while ( have_posts() ) {
	the_post();
	TOKB_Single::render( get_post() );
}
get_footer();
