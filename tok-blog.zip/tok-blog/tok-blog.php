<?php
/**
 * Plugin Name:       TOKCONSULT Blog
 * Description:       Shows your WordPress posts in the TOKCONSULT design: the blog listing and every article page. New posts appear automatically, in the same design. Shortcodes: [tok_blog] for the full blog page, [tok_blog_latest] for a row of recent posts on any page.
 * Version:           1.1.0
 * Author:            TOKCONSULT
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Text Domain:       tok-blog
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'TOKB_DIR', plugin_dir_path( __FILE__ ) );
define( 'TOKB_VER', '1.1.0' );
require_once TOKB_DIR . 'includes/class-single.php';

final class TOKB_Blog {

	private static $printed_css = false;

	public static function init() {
		add_shortcode( 'tok_blog', array( __CLASS__, 'blog' ) );
		add_shortcode( 'tok_blog_latest', array( __CLASS__, 'latest' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'fonts' ) );
	}

	public static function fonts() {
		global $post;
		if ( is_a( $post, 'WP_Post' ) && ( has_shortcode( $post->post_content, 'tok_blog' ) || has_shortcode( $post->post_content, 'tok_blog_latest' ) ) ) {
			wp_enqueue_style( 'tokb-fonts', 'https://fonts.googleapis.com/css2?family=Sora:wght@600;700;800&family=DM+Sans:opsz,wght@9..40,400;9..40,500;9..40,700&display=swap', array(), null );
		}
	}

	/** Inline the stylesheet once per page (works inside Elementor widgets and page builders). */
	private static function css() {
		if ( self::$printed_css ) {
			return '';
		}
		self::$printed_css = true;
		$css = file_get_contents( TOKB_DIR . 'assets/blog.css' ); // phpcs:ignore
		return '<style id="tokb-css">' . $css . '</style>';
	}

	/* ---------- data helpers ---------- */

	private static function card_data( $p ) {
		$cats    = get_the_category( $p->ID );
		$cat     = $cats ? $cats[0] : null;
		$words   = str_word_count( wp_strip_all_tags( (string) $p->post_content ) );
		$excerpt = has_excerpt( $p->ID ) ? get_the_excerpt( $p ) : wp_trim_words( wp_strip_all_tags( strip_shortcodes( (string) $p->post_content ) ), 26, '…' );
		return array(
			'url'     => get_permalink( $p ),
			'title'   => get_the_title( $p ),
			'img'     => get_the_post_thumbnail_url( $p, 'large' ),
			'alt'     => get_post_meta( get_post_thumbnail_id( $p ), '_wp_attachment_image_alt', true ),
			'cat'     => $cat ? $cat->name : '',
			'date'    => get_the_date( 'j M Y', $p ),
			'mins'    => max( 1, (int) ceil( $words / 200 ) ),
			'excerpt' => $excerpt,
		);
	}

	private static function thumb( $d, $class = 'tokb-thumb' ) {
		if ( $d['img'] ) {
			return '<div class="' . $class . '"><img src="' . esc_url( $d['img'] ) . '" alt="' . esc_attr( $d['alt'] ) . '" loading="lazy"></div>';
		}
		// Branded fallback when a post has no featured image.
		return '<div class="' . $class . ' tokb-noimg" aria-hidden="true"><span class="tokb-bar"></span><span class="tokb-noimg-t">' . esc_html( $d['cat'] ? $d['cat'] : 'TOKCONSULT' ) . '</span></div>';
	}

	private static function meta( $d ) {
		return '<p class="tokb-meta">' . esc_html( $d['date'] ) . ' <span aria-hidden="true">·</span> ' . esc_html( $d['mins'] ) . ' min read</p>';
	}

	private static function card( $p ) {
		$d = self::card_data( $p );
		$h = '<article class="tokb-card"><a class="tokb-cardlink" href="' . esc_url( $d['url'] ) . '">';
		$h .= self::thumb( $d );
		if ( $d['cat'] ) {
			$h .= '<span class="tokb-cat">' . esc_html( $d['cat'] ) . '</span>';
		}
		$h .= '<h3 class="tokb-title">' . esc_html( $d['title'] ) . '</h3>';
		$h .= '<p class="tokb-excerpt">' . esc_html( $d['excerpt'] ) . '</p>';
		$h .= self::meta( $d ) . '</a></article>';
		return $h;
	}

	private static function featured( $p ) {
		$d = self::card_data( $p );
		$h = '<article class="tokb-feat"><a class="tokb-featlink" href="' . esc_url( $d['url'] ) . '">';
		$h .= self::thumb( $d, 'tokb-thumb tokb-featimg' );
		$h .= '<div class="tokb-featbody"><span class="tokb-cat">' . esc_html( $d['cat'] ? 'Latest · ' . $d['cat'] : 'Latest' ) . '</span>';
		$h .= '<h2 class="tokb-feattitle">' . esc_html( $d['title'] ) . '</h2>';
		$h .= '<p class="tokb-excerpt tokb-featex">' . esc_html( $d['excerpt'] ) . '</p>';
		$h .= self::meta( $d ) . '<span class="tokb-more">Read the article <span aria-hidden="true">→</span></span></div></a></article>';
		return $h;
	}

	private static function page_url( $args ) {
		$base = remove_query_arg( array( 'tok_topic', 'tok_pg' ) );
		$args = array_filter( $args );
		return $args ? add_query_arg( $args, $base ) : $base;
	}

	/* ---------- [tok_blog] ---------- */

	public static function blog( $atts ) {
		$a     = shortcode_atts( array( 'per_page' => 9, 'filters' => 'yes', 'featured' => 'yes' ), $atts, 'tok_blog' );
		$per   = max( 1, min( 30, absint( $a['per_page'] ) ) );
		$topic = isset( $_GET['tok_topic'] ) ? sanitize_title( wp_unslash( $_GET['tok_topic'] ) ) : ''; // phpcs:ignore
		$pg    = isset( $_GET['tok_pg'] ) ? max( 1, absint( $_GET['tok_pg'] ) ) : 1; // phpcs:ignore

		$args = array(
			'post_type'           => 'post',
			'post_status'         => 'publish',
			'posts_per_page'      => $per,
			'paged'               => $pg,
			'ignore_sticky_posts' => true,
		);
		if ( $topic ) {
			$args['category_name'] = $topic;
		}
		$q     = new WP_Query( $args );
		$posts = $q->posts;

		$out = self::css() . '<div class="tokb" id="tokb">';

		// Topic chips: only categories that have posts.
		if ( 'yes' === $a['filters'] ) {
			$cats = get_categories( array( 'hide_empty' => true, 'orderby' => 'count', 'order' => 'DESC', 'number' => 8 ) );
			$cats = array_filter( $cats, function ( $c ) { return 'uncategorized' !== $c->slug; } );
			if ( $cats ) {
				$out .= '<nav class="tokb-chips" aria-label="Blog topics">';
				$out .= '<a class="tokb-chip' . ( $topic ? '' : ' tokb-on' ) . '" href="' . esc_url( self::page_url( array() ) . '#tokb' ) . '"' . ( $topic ? '' : ' aria-current="page"' ) . '>All</a>';
				foreach ( $cats as $c ) {
					$on   = $topic === $c->slug;
					$out .= '<a class="tokb-chip' . ( $on ? ' tokb-on' : '' ) . '" href="' . esc_url( self::page_url( array( 'tok_topic' => $c->slug ) ) . '#tokb' ) . '"' . ( $on ? ' aria-current="page"' : '' ) . '>' . esc_html( $c->name ) . '</a>';
				}
				$out .= '</nav>';
			}
		}

		if ( ! $posts ) {
			$out .= '<div class="tokb-empty"><h3>New articles are on the way.</h3><p>We’re writing practical guides for Nigerian founders. Check back soon.</p></div></div>';
			return $out;
		}

		if ( 'yes' === $a['featured'] && 1 === $pg && ! $topic ) {
			$out .= self::featured( array_shift( $posts ) );
		}
		if ( $posts ) {
			$out .= '<div class="tokb-grid">';
			foreach ( $posts as $p ) {
				$out .= self::card( $p );
			}
			$out .= '</div>';
		}

		// Pagination.
		$max = (int) $q->max_num_pages;
		if ( $max > 1 ) {
			$out .= '<nav class="tokb-pager" aria-label="More articles">';
			if ( $pg > 1 ) {
				$out .= '<a class="tokb-pbtn" href="' . esc_url( self::page_url( array( 'tok_topic' => $topic, 'tok_pg' => $pg - 1 > 1 ? $pg - 1 : 0 ) ) . '#tokb' ) . '">← Newer</a>';
			}
			for ( $i = 1; $i <= $max; $i++ ) {
				$out .= ( $i === $pg )
					? '<span class="tokb-pnum tokb-on" aria-current="page">' . $i . '</span>'
					: '<a class="tokb-pnum" href="' . esc_url( self::page_url( array( 'tok_topic' => $topic, 'tok_pg' => $i > 1 ? $i : 0 ) ) . '#tokb' ) . '">' . $i . '</a>';
			}
			if ( $pg < $max ) {
				$out .= '<a class="tokb-pbtn" href="' . esc_url( self::page_url( array( 'tok_topic' => $topic, 'tok_pg' => $pg + 1 ) ) . '#tokb' ) . '">Older →</a>';
			}
			$out .= '</nav>';
		}

		wp_reset_postdata();
		return $out . '</div>';
	}

	/* ---------- [tok_blog_latest] ---------- */

	public static function latest( $atts ) {
		$a     = shortcode_atts( array( 'count' => 3, 'topic' => '', 'link' => '/blog/', 'link_text' => 'See all articles' ), $atts, 'tok_blog_latest' );
		$args  = array(
			'post_type'           => 'post',
			'post_status'         => 'publish',
			'posts_per_page'      => max( 1, min( 12, absint( $a['count'] ) ) ),
			'ignore_sticky_posts' => true,
			'no_found_rows'       => true,
		);
		if ( $a['topic'] ) {
			$args['category_name'] = sanitize_title( $a['topic'] );
		}
		$posts = get_posts( $args );
		if ( ! $posts ) {
			return '';
		}
		$out = self::css() . '<div class="tokb tokb-latest"><div class="tokb-grid">';
		foreach ( $posts as $p ) {
			$out .= self::card( $p );
		}
		$out .= '</div>';
		if ( $a['link'] ) {
			$out .= '<p class="tokb-all"><a class="tokb-more" href="' . esc_url( $a['link'] ) . '">' . esc_html( $a['link_text'] ) . ' <span aria-hidden="true">→</span></a></p>';
		}
		return $out . '</div>';
	}
}

TOKB_Blog::init();
TOKB_Single::init();
