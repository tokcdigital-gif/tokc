(function () {
  // Reading progress bar
  var bar = document.createElement('div');
  bar.setAttribute('aria-hidden', 'true');
  bar.style.cssText = 'position:fixed;top:0;left:0;height:3px;width:0;background:#E75A4E;z-index:99999;transition:width .1s linear';
  document.body.appendChild(bar);
  var body = document.getElementById('tokp-body');
  function progress() {
    if (!body) { return; }
    var r = body.getBoundingClientRect();
    var total = r.height - window.innerHeight * 0.6;
    var done = Math.min(Math.max(-r.top + window.innerHeight * 0.2, 0), total > 0 ? total : 1);
    bar.style.width = (total > 0 ? (done / total) * 100 : 0) + '%';
  }
  window.addEventListener('scroll', progress, { passive: true });
  window.addEventListener('resize', progress);
  progress();

  // Highlight the current section in "On this page"
  var links = Array.prototype.slice.call(document.querySelectorAll('.toc a[href^="#"]'));
  if (links.length && 'IntersectionObserver' in window) {
    var map = {};
    links.forEach(function (a) { map[decodeURIComponent(a.getAttribute('href').slice(1))] = a; });
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) {
          links.forEach(function (a) { a.classList.remove('on'); });
          var a = map[e.target.id];
          if (a) { a.classList.add('on'); }
        }
      });
    }, { rootMargin: '-20% 0px -70% 0px' });
    Object.keys(map).forEach(function (id) { var h = document.getElementById(id); if (h) { io.observe(h); } });
  }

  // Copy link
  Array.prototype.forEach.call(document.querySelectorAll('[data-tokp-copy]'), function (b) {
    b.addEventListener('click', function () {
      var url = b.getAttribute('data-tokp-copy') || location.href;
      var label = b.getAttribute('aria-label');
      function ok() { b.setAttribute('aria-label', 'Link copied'); b.style.borderColor = '#167A4A'; setTimeout(function () { b.setAttribute('aria-label', label); b.style.borderColor = ''; }, 1800); }
      if (navigator.clipboard) { navigator.clipboard.writeText(url).then(ok, function () { window.prompt('Copy this link', url); }); }
      else { window.prompt('Copy this link', url); }
    });
  });
})();
