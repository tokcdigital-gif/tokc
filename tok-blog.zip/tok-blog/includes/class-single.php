<?php
/**
 * The TOKCONSULT article page: every blog post is shown in this design automatically.
 * The layout lives in templates/single-post.html (built from the design canvas);
 * this class fills its %%SLOTS%% with the post's own content.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class TOKB_Single {

	public static function init() {
		add_filter( 'template_include', array( __CLASS__, 'template' ), 99 );
		add_filter( 'body_class', array( __CLASS__, 'body_class' ), 99 );
		add_filter( 'astra_page_layout', array( __CLASS__, 'astra_no_sidebar' ), 99 );
		add_filter( 'astra_get_content_layout', array( __CLASS__, 'astra_full_width' ), 99 );
		add_action( 'wp_head', array( __CLASS__, 'head_css' ), 99 );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'assets' ) );
	}

	public static function active() {
		return is_singular( 'post' ) && ! is_embed() && apply_filters( 'tokb_single_enabled', true );
	}

	public static function template( $template ) {
		return self::active() ? TOKB_DIR . 'templates/single.php' : $template;
	}

	public static function body_class( $classes ) {
		if ( ! self::active() ) {
			return $classes;
		}
		$drop = array( 'ast-right-sidebar', 'ast-left-sidebar', 'ast-separate-container', 'ast-two-container', 'ast-box-layout' );
		$classes = array_values( array_diff( $classes, $drop ) );
		return array_merge( $classes, array( 'ast-no-sidebar', 'ast-plain-container', 'ast-page-builder-template', 'tokp-single' ) );
	}

	public static function astra_no_sidebar( $layout ) {
		return self::active() ? 'no-sidebar' : $layout;
	}

	public static function astra_full_width( $layout ) {
		return self::active() ? 'page-builder' : $layout;
	}

	/** Let the article run edge to edge inside any theme's content wrapper. */
	public static function head_css() {
		if ( ! self::active() ) {
			return;
		}
		echo '<style id="tokp-wrap">body.tokp-single .site-content>.ast-container,body.tokp-single #content>.container,body.tokp-single .site-content>.container{max-width:100%!important;width:100%!important;padding:0!important;margin:0!important;display:block!important}body.tokp-single #primary,body.tokp-single .content-area{margin:0!important;padding:0!important;width:100%!important;float:none!important}body.tokp-single{background:#FFFFFF!important}html{scroll-behavior:smooth}</style>' . "\n";
	}

	public static function assets() {
		if ( self::active() ) {
			wp_enqueue_script( 'tokp-post', plugins_url( 'assets/post.js', TOKB_DIR . 'tok-blog.php' ), array(), TOKB_VER, true );
		}
	}

	/* ---------- slot builders ---------- */

	private static function primary_cat( $post ) {
		$cats = get_the_category( $post->ID );
		foreach ( $cats as $c ) {
			if ( 'uncategorized' !== $c->slug ) {
				return $c;
			}
		}
		return null;
	}

	private static function minutes( $post ) {
		return max( 1, (int) ceil( str_word_count( wp_strip_all_tags( (string) $post->post_content ) ) / 200 ) );
	}

	/** Adds ids to H2 headings and returns array( $html, $toc_items ). */
	public static function with_anchors( $html ) {
		$items = array();
		$used  = array();
		$html  = preg_replace_callback(
			'#<h2([^>]*)>(.*?)</h2>#is',
			function ( $m ) use ( &$items, &$used ) {
				$attrs = $m[1];
				$text  = trim( wp_strip_all_tags( $m[2] ) );
				if ( '' === $text ) {
					return $m[0];
				}
				if ( preg_match( '/\sid=["\']([^"\']+)["\']/i', $attrs, $idm ) ) {
					$id = $idm[1];
				} else {
					$base = sanitize_title( $text );
					$base = $base ? $base : 'section';
					$id   = $base;
					$n    = 2;
					while ( isset( $used[ $id ] ) ) {
						$id = $base . '-' . $n++;
					}
					$attrs .= ' id="' . esc_attr( $id ) . '"';
				}
				$used[ $id ] = true;
				$items[]     = array( $id, $text );
				return '<h2' . $attrs . '>' . $m[2] . '</h2>';
			},
			$html
		);
		return array( $html, $items );
	}

	private static function plug( $cat ) {
		$slug = $cat ? $cat->slug . ' ' . strtolower( $cat->name ) : '';
		$p    = array( 'Free tool', 'Business Health Check', '15 yes-or-no questions and an instant score across money, market, operations, growth and risk.', 'https://tokconsult.com.ng/free-health-check/', 'Take the free Health Check' );
		if ( false !== strpos( $slug, 'launch' ) || false !== strpos( $slug, 'regist' ) ) {
			$p = array( 'Do it the easy way', 'Launch Kit', 'Registration guide, brand templates, business plan, pitch deck and a 90-day planner, in one download.', 'https://selar.com/tokclaunchkit', 'Get the Launch Kit · ₦50,000' );
		} elseif ( false !== strpos( $slug, 'operation' ) || false !== strpos( $slug, 'hr' ) || false !== strpos( $slug, 'structur' ) ) {
			$p = array( 'Ready-made documents', 'Business in a Box', '150+ editable documents to hire, pay, govern, sell and stay compliant, written for Nigerian law.', 'https://tokconsult.com.ng/business-in-a-box/', 'See what’s inside' );
		} elseif ( false !== strpos( $slug, 'growth' ) || false !== strpos( $slug, 'sales' ) || false !== strpos( $slug, 'pric' ) ) {
			$p = array( 'Ready-to-use sales tools', 'Growth Toolkit', 'Sales scripts, a pricing calculator and trackers to turn more enquiries into paying customers.', 'https://selar.com/tokgrowthtoolkit', 'Get the Growth Toolkit · ₦35,000' );
		}
		return '<div class="plug"><div class="plug-t"><span>' . esc_html( $p[0] ) . '</span><h3>' . esc_html( $p[1] ) . '</h3><p>' . esc_html( $p[2] ) . '</p></div><a class="btn btn-w" href="' . esc_url( $p[3] ) . '">' . esc_html( $p[4] ) . '</a></div>';
	}

	private static function share( $url, $title ) {
		$u = rawurlencode( $url );
		$t = rawurlencode( $title );
		$icons = array(
			'wa' => '<svg aria-hidden="true" width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.2a9.7 9.7 0 0 0-8.4 14.6L2.3 21.7l5-1.3A9.7 9.7 0 1 0 12 2.2zm0 17.7c-1.5 0-2.9-.4-4.1-1.1l-.3-.2-3 .8.8-2.9-.2-.3A8 8 0 1 1 12 19.9zm4.4-6c-.2-.1-1.4-.7-1.7-.8-.2-.1-.4-.1-.5.1l-.8.9c-.1.2-.3.2-.5.1a6.5 6.5 0 0 1-3.3-2.9c-.2-.4.2-.4.7-1.3.1-.2 0-.3 0-.4l-.8-1.8c-.2-.5-.4-.4-.5-.4h-.5a.9.9 0 0 0-.7.3 2.8 2.8 0 0 0-.9 2.1 4.9 4.9 0 0 0 1 2.6 11.2 11.2 0 0 0 4.3 3.8c1.6.7 2.2.7 3 .6.5-.1 1.4-.6 1.6-1.2s.2-1.1.1-1.2l-.5-.4z"></path></svg>',
			'li' => '<svg aria-hidden="true" width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M4.98 3.5a2.5 2.5 0 1 1 0 5 2.5 2.5 0 0 1 0-5zM3 9.75h4v11H3zM9.5 9.75h3.8v1.5h.1c.5-1 1.8-1.8 3.7-1.8 4 0 4.7 2.6 4.7 6v6.1h-4v-5.4c0-1.3 0-3-1.8-3s-2.1 1.4-2.1 2.9v5.5h-4z"></path></svg>',
			'x'  => '<svg aria-hidden="true" width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M17.8 3h3.1l-6.8 7.7L22 21h-6.2l-4.9-6.3L5.3 21H2.2l7.2-8.3L2 3h6.4l4.4 5.8zm-1.1 16.2h1.7L7.4 4.7H5.6z"></path></svg>',
			'cp' => '<svg aria-hidden="true" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M10 14a4.5 4.5 0 0 0 6.4 0l3-3a4.5 4.5 0 0 0-6.4-6.4l-1 1"></path><path d="M14 10a4.5 4.5 0 0 0-6.4 0l-3 3a4.5 4.5 0 0 0 6.4 6.4l1-1"></path></svg>',
		);
		return '<span>Share this article</span>'
			. '<a class="sh" href="https://wa.me/?text=' . $t . '%20' . $u . '" target="_blank" rel="noopener" aria-label="Share on WhatsApp">' . $icons['wa'] . '</a>'
			. '<a class="sh" href="https://www.linkedin.com/sharing/share-offsite/?url=' . $u . '" target="_blank" rel="noopener" aria-label="Share on LinkedIn">' . $icons['li'] . '</a>'
			. '<a class="sh" href="https://x.com/intent/post?url=' . $u . '&amp;text=' . $t . '" target="_blank" rel="noopener" aria-label="Share on X">' . $icons['x'] . '</a>'
			. '<button class="sh" type="button" data-tokp-copy="' . esc_url( $url ) . '" aria-label="Copy link">' . $icons['cp'] . '</button>';
	}

	private static function related( $post, $cat ) {
		$args = array( 'post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => 3, 'post__not_in' => array( $post->ID ), 'ignore_sticky_posts' => true, 'no_found_rows' => true );
		if ( $cat ) {
			$args['cat'] = $cat->term_id;
		}
		$posts = get_posts( $args );
		if ( count( $posts ) < 3 ) {
			$args['post__not_in'] = array_merge( array( $post->ID ), wp_list_pluck( $posts, 'ID' ) );
			unset( $args['cat'] );
			$args['posts_per_page'] = 3 - count( $posts );
			$posts                  = array_merge( $posts, get_posts( $args ) );
		}
		$out = '';
		foreach ( $posts as $p ) {
			$c    = self::primary_cat( $p );
			$img  = get_the_post_thumbnail_url( $p, 'large' );
			$out .= '<a class="rc" href="' . esc_url( get_permalink( $p ) ) . '"><div class="rc-img">'
				. ( $img ? '<img src="' . esc_url( $img ) . '" alt="" loading="lazy">' : '' )
				. '</div>' . ( $c ? '<span>' . esc_html( $c->name ) . '</span>' : '' )
				. '<h3>' . esc_html( get_the_title( $p ) ) . '</h3><p>' . esc_html( get_the_date( 'j M Y', $p ) ) . ' · ' . self::minutes( $p ) . ' min read</p></a>';
		}
		return $out;
	}

	/** Build every slot for the current post. */
	public static function slots( $post ) {
		$cat     = self::primary_cat( $post );
		$title   = get_the_title( $post );
		$url     = get_permalink( $post );
		$blog    = home_url( '/blog/' );
		$content = apply_filters( 'the_content', get_the_content( null, false, $post ) );
		$content = str_replace( ']]>', ']]&gt;', $content );
		list( $content, $toc_items ) = self::with_anchors( $content );

		$dek = has_excerpt( $post ) ? get_the_excerpt( $post ) : '';

		$author = get_the_author_meta( 'display_name', $post->post_author );
		if ( ! $author || preg_match( '/^(admin|administrator)$/i', $author ) ) {
			$author = 'TOKCONSULT team';
		}

		$img   = get_the_post_thumbnail_url( $post, 'full' );
		$cover = $img ? '<div class="wrap"><div class="cover"><img src="' . esc_url( $img ) . '" alt="' . esc_attr( $title ) . '"></div></div>' : '<div class="wrap"><div style="height: 8px"></div></div>';

		$toc = '';
		if ( count( $toc_items ) >= 2 ) {
			$toc = '<nav class="toc" aria-label="On this page"><p>On this page</p>';
			foreach ( $toc_items as $it ) {
				$toc .= '<a href="#' . esc_attr( $it[0] ) . '">' . esc_html( $it[1] ) . '</a>';
			}
			$toc .= '</nav>';
		}

		$tags = '';
		$tl   = get_the_tags( $post->ID );
		if ( $tl ) {
			$tags = '<div class="tags">';
			foreach ( $tl as $t ) {
				$tags .= '<span class="tag-chip" style="display: inline-flex; align-items: center; min-height: 36px; padding: 0 14px; border-radius: 99px; background: #F5F6F8; color: #3A4257; font-size: 14px; font-weight: 700">' . esc_html( $t->name ) . '</span>';
			}
			$tags .= '</div>';
		}

		$crumb = '<a href="' . esc_url( $blog ) . '">Blog</a>';
		if ( $cat ) {
			$crumb .= '<span aria-hidden="true">/</span><a href="' . esc_url( add_query_arg( 'tok_topic', $cat->slug, $blog ) ) . '">' . esc_html( $cat->name ) . '</a>';
		}

		$meta = '<span class="by"><span class="mark" aria-hidden="true"></span>' . esc_html( $author ) . '</span>'
			. '<span class="dot" aria-hidden="true"></span><span>' . esc_html( get_the_date( 'j M Y', $post ) ) . '</span>'
			. '<span class="dot" aria-hidden="true"></span><span>' . self::minutes( $post ) . ' min read</span>';

		$related = self::related( $post, $cat );

		return array(
			'%%CRUMB%%'   => $crumb,
			'%%CAT%%'     => esc_html( $cat ? $cat->name : 'Article' ),
			'%%TITLE%%'   => esc_html( $title ),
			'%%DEK%%'     => esc_html( $dek ),
			'%%META%%'    => $meta,
			'%%COVER%%'   => $cover,
			'%%CONTENT%%' => $content,
			'%%TAGS%%'    => $tags,
			'%%SHARE%%'   => self::share( $url, $title ),
			'%%PLUG%%'    => self::plug( $cat ),
			'%%TOC%%'     => $toc,
			'%%RELATED%%' => $related,
		);
	}

	/** Render the page body (called by templates/single.php inside the theme's header and footer). */
	public static function render( $post ) {
		$html = file_get_contents( TOKB_DIR . 'templates/single-post.html' ); // phpcs:ignore
		$map  = self::slots( $post );
		if ( '' === $map['%%DEK%%'] ) {
			$html = preg_replace( '#<p class="dek">%%DEK%%</p>#', '', $html );
		}
		if ( ! get_the_post_thumbnail_url( $post, 'full' ) ) {
			$html = str_replace( '<header class="ph">', '<header class="ph ph-flat">', $html );
		}
		if ( '' === $map['%%RELATED%%'] ) {
			$html = preg_replace( '#<section[^>]*class="more".*?</section>#s', '', $html );
		}
		// Content goes in last so text inside a post can never be mistaken for a slot.
		$content = $map['%%CONTENT%%'];
		unset( $map['%%CONTENT%%'] );
		$parts = explode( '%%CONTENT%%', $html, 2 );
		$out   = strtr( $parts[0], $map ) . $content . ( isset( $parts[1] ) ? strtr( $parts[1], $map ) : '' );
		echo $out; // phpcs:ignore -- each slot is escaped where it is built; content comes from the_content.
	}
}
