<?php
/**
 * Plugin Name:       TOKCONSULT Header & Menu
 * Description:       The TOKCONSULT site header: logo, menu with Services and Resources drop-downs, a Health Check button, and a full-screen mobile menu. Replaces the theme's header on every page and keeps TOKCONSULT pages full width. No setup needed.
 * Version:           1.0.1
 * Author:            TOKCONSULT
 * Requires at least: 6.0
 * Requires PHP:      7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class TOKH_Header {

	const SITE = 'https://tokconsult.com.ng';

	private static $done = false;

	public static function init() {
		add_action( 'wp_head', array( __CLASS__, 'head' ), 5 );
		add_action( 'wp_body_open', array( __CLASS__, 'render' ), 5 );
		add_action( 'wp_footer', array( __CLASS__, 'footer' ), 5 );
	}

	private static function enabled() {
		if ( is_admin() || is_feed() || is_embed() || is_customize_preview() ) {
			return false;
		}
		if ( isset( $_GET['elementor-preview'] ) || isset( $_GET['brizy-edit'] ) || isset( $_GET['brizy-edit-iframe'] ) || isset( $_GET['fl_builder'] ) ) { // phpcs:ignore
			return false;
		}
		return (bool) apply_filters( 'tokh_enabled', true );
	}

	/* ---------- menu data ---------- */

	public static function menu() {
		$s = self::SITE;
		return array(
			array( 'label' => 'About', 'url' => $s . '/about/' ),
			array(
				'label' => 'Services',
				'type'  => 'svc',
				'items' => array(
					array( 'Business Audit & Advisory', 'Find what’s working, what’s leaking and what to fix first.', $s . '/business-audit-advisory/', 'audit' ),
					array( 'Market Launch & Entry', 'Registered, branded, online and ready to sell.', $s . '/market-launch-entry/', 'launch' ),
					array( 'Business Operations & Structuring', 'Policies, SOPs, systems and AI agents that run without you.', $s . '/operations-structuring/', 'ops' ),
					array( 'Growth & Revenue', 'A six-week sprint to fix your offer, pricing and sales.', $s . '/growth-revenue/', 'growth' ),
					array( 'Partner Plan', 'We stay on monthly, with a fixed set of deliverables.', $s . '/partner-plan/', 'partner' ),
				),
				'foot'  => array( 'Not sure where to start? Take the free Health Check.', 'See prices & bundles →', $s . '/packages-and-bundles/' ),
			),
			array(
				'label' => 'Resources',
				'type'  => 'res',
				'items' => array(
					array( 'Blog & Insights', 'Practical articles for Nigerian founders and growing businesses.', $s . '/blog/', 'blog' ),
					array( 'Free Tools & Guides', 'The Business Health Check, free guides and checklists.', $s . '/resources/', 'tools' ),
				),
			),
			array( 'label' => 'Shop', 'url' => $s . '/shop/' ),
			array( 'label' => 'Contact', 'url' => $s . '/contact-us/' ),
		);
	}

	private static function icon( $k ) {
		$i = array(
			'audit'   => '<path d="M12 3v18M16.5 7.5C16 6 14.3 5 12 5 9.5 5 7.5 6.3 7.5 8.3c0 4.4 9 2.6 9 7 0 2-2 3.4-4.5 3.4-2.4 0-4.2-1-4.8-2.7"></path>',
			'launch'  => '<path d="M5 15c-1.5 1.5-2 5-2 5s3.5-.5 5-2"></path><path d="M9 15l-3-3c1.5-4.5 5-8 11-9 0 6-3.5 9.5-8 11z"></path><circle cx="15" cy="9" r="1.6"></circle>',
			'ops'     => '<circle cx="12" cy="12" r="3"></circle><path d="M12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3M5.3 5.3l2.1 2.1M16.6 16.6l2.1 2.1M5.3 18.7l2.1-2.1M16.6 7.4l2.1-2.1"></path>',
			'growth'  => '<path d="M3 17l6-6 4 4 8-8"></path><path d="M15 7h6v6"></path>',
			'partner' => '<path d="M8 11a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM16 11a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"></path><path d="M2.5 20c.6-3 2.8-5 5.5-5s4.9 2 5.5 5M13.5 15.4c.8-.3 1.6-.4 2.5-.4 2.7 0 4.9 2 5.5 5"></path>',
			'blog'    => '<path d="M5 4h11l3 3v13H5z"></path><path d="M9 10h7M9 14h7M9 18h4"></path>',
			'price'   => '<path d="M20.6 13.4l-7.2 7.2a2 2 0 0 1-2.8 0L3 13V3h10l7.6 7.6a2 2 0 0 1 0 2.8z"></path><circle cx="7.5" cy="7.5" r="1.5"></circle>',
			'tools'   => '<path d="M9 12l2 2 4-4"></path><path d="M12 3l7 3v5c0 4.5-3 8.3-7 10-4-1.7-7-5.5-7-10V6z"></path>',
		);
		return '<span class="tokh-ico" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' . $i[ $k ] . '</svg></span>';
	}

	private static function chev() {
		return '<svg class="tokh-chev" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 9l6 6 6-6"></path></svg>';
	}

	private static function path_of( $url ) {
		$p = (string) wp_parse_url( $url, PHP_URL_PATH );
		return '/' . trim( $p, '/' ) . '/';
	}

	private static function current_path() {
		$uri = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '/'; // phpcs:ignore
		$p   = (string) wp_parse_url( $uri, PHP_URL_PATH );
		$p   = '/' . trim( $p, '/' ) . '/';
		return '//' === $p ? '/' : $p;
	}

	private static function is_current( $url ) {
		$cur = self::current_path();
		$p   = self::path_of( $url );
		if ( '/blog/' === $p && function_exists( 'is_singular' ) && is_singular( 'post' ) ) {
			return true; // blog posts sit under Blog & Insights
		}
		return $cur === $p;
	}

	/* ---------- output ---------- */

	public static function head() {
		if ( self::enabled() ) {
			echo '<style id="tokh-css">' . self::CSS . '</style>' . "\n"; // phpcs:ignore
		}
	}

	public static function render() {
		if ( ! self::enabled() || self::$done ) {
			return;
		}
		self::$done = true;
		$s     = self::SITE;
		$menu  = self::menu();
		$desk  = '';
		$mob   = '';
		$n     = 0;

		foreach ( $menu as $m ) {
			$n++;
			if ( empty( $m['items'] ) ) {
				$act   = self::is_current( $m['url'] ) ? ' tokh-active' : '';
				$aria  = $act ? ' aria-current="page"' : '';
				$desk .= '<li class="tokh-item"><a class="tokh-link' . $act . '" href="' . esc_url( $m['url'] ) . '"' . $aria . '>' . esc_html( $m['label'] ) . '</a></li>';
				$mob  .= '<li class="tokh-m-item"><a class="tokh-m-link' . $act . '" href="' . esc_url( $m['url'] ) . '"' . $aria . '>' . esc_html( $m['label'] ) . '</a></li>';
				continue;
			}
			$parent_active = false;
			$cards         = '';
			$sub           = '';
			foreach ( $m['items'] as $it ) {
				$on = self::is_current( $it[2] );
				$parent_active = $parent_active || $on;
				$cl    = $on ? ' tokh-active' : '';
				$aria  = $on ? ' aria-current="page"' : '';
				$cards .= '<li><a class="tokh-card' . $cl . '" href="' . esc_url( $it[2] ) . '"' . $aria . '>' . self::icon( $it[3] ) . '<span class="tokh-card-t"><strong>' . esc_html( $it[0] ) . '</strong><span>' . esc_html( $it[1] ) . '</span></span></a></li>';
				$sub   .= '<a href="' . esc_url( $it[2] ) . '" class="' . trim( $cl ) . '"' . $aria . '>' . self::icon( $it[3] ) . esc_html( $it[0] ) . '</a>';
			}
			$foot = '';
			if ( ! empty( $m['foot'] ) ) {
				$foot = '<div class="tokh-foot"><span>Not sure where to start? <a href="' . esc_url( $s . '/free-health-check/' ) . '">Take the free Health Check</a></span><a href="' . esc_url( $m['foot'][2] ) . '">' . esc_html( $m['foot'][1] ) . '</a></div>';
				$sub .= '<a href="' . esc_url( $m['foot'][2] ) . '">' . self::icon( 'price' ) . 'Prices &amp; bundles</a>';
			}
			$id    = 'tokh-p' . $n;
			$pa    = $parent_active ? ' tokh-active' : '';
			$desk .= '<li class="tokh-item tokh-has"><button type="button" class="tokh-link' . $pa . '" aria-expanded="false" aria-controls="' . $id . '">' . esc_html( $m['label'] ) . self::chev() . '</button>'
				. '<div class="tokh-panel tokh-panel-' . esc_attr( $m['type'] ) . '" id="' . $id . '"><ul class="tokh-grid">' . $cards . '</ul>' . $foot . '</div></li>';
			$mob  .= '<li class="tokh-m-item tokh-has' . ( $parent_active ? ' tokh-open' : '' ) . '"><button type="button" class="tokh-m-link' . $pa . '" aria-expanded="' . ( $parent_active ? 'true' : 'false' ) . '">' . esc_html( $m['label'] ) . self::chev() . '</button><div class="tokh-m-sub">' . $sub . '</div></li>';
		}

		$wa = '<svg aria-hidden="true" width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.2a9.7 9.7 0 0 0-8.4 14.6L2.3 21.7l5-1.3A9.7 9.7 0 1 0 12 2.2zm0 17.7c-1.5 0-2.9-.4-4.1-1.1l-.3-.2-3 .8.8-2.9-.2-.3A8 8 0 1 1 12 19.9zm4.4-6c-.2-.1-1.4-.7-1.7-.8-.2-.1-.4-.1-.5.1l-.8.9c-.1.2-.3.2-.5.1a6.5 6.5 0 0 1-3.3-2.9c-.2-.4.2-.4.7-1.3.1-.2 0-.3 0-.4l-.8-1.8c-.2-.5-.4-.4-.5-.4h-.5a.9.9 0 0 0-.7.3 2.8 2.8 0 0 0-.9 2.1 4.9 4.9 0 0 0 1 2.6 11.2 11.2 0 0 0 4.3 3.8c1.6.7 2.2.7 3 .6.5-.1 1.4-.6 1.6-1.2s.2-1.1.1-1.2l-.5-.4z"></path></svg>';

		echo '<header id="tokh" class="tokh"><div class="tokh-in">'
			. '<a class="tokh-logo" href="' . esc_url( $s . '/' ) . '" aria-label="TOKCONSULT home">' . self::LOGO . '</a>'
			. '<nav class="tokh-nav" aria-label="Main menu"><ul class="tokh-menu">' . $desk . '</ul></nav>'
			. '<div class="tokh-right"><a class="tokh-cta" href="' . esc_url( $s . '/free-health-check/' ) . '">Free Health Check</a>'
			. '<button type="button" class="tokh-burger" aria-expanded="false" aria-controls="tokh-mobile" aria-label="Open menu"><span></span></button></div>'
			. '</div>'
			. '<nav class="tokh-mobile" id="tokh-mobile" aria-label="Mobile menu" aria-hidden="true"><ul class="tokh-m-list">' . $mob . '</ul>'
			. '<div class="tokh-m-ctas"><a class="tokh-cta" href="' . esc_url( $s . '/free-health-check/' ) . '">Take the free Health Check</a><a class="tokh-wa" href="https://wa.link/k3be0i">' . $wa . 'Chat with us on WhatsApp</a></div>'
			. '<p class="tokh-m-note">We reply within one working day.</p></nav>'
			. '</header><div id="tokh-space" aria-hidden="true"></div>' . "\n"; // phpcs:ignore -- built from escaped parts
	}

	public static function footer() {
		if ( ! self::enabled() ) {
			return;
		}
		if ( ! self::$done ) {
			// Theme without wp_body_open: print the header and move it to the top of the page.
			self::render();
			echo '<script>(function(){var h=document.getElementById("tokh"),s=document.getElementById("tokh-space");if(h){document.body.insertBefore(s,document.body.firstChild);document.body.insertBefore(h,document.body.firstChild);}})();</script>';
		}
		echo '<script id="tokh-js">' . self::JS . '</script>' . "\n"; // phpcs:ignore
	}

	const LOGO = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 775 115" role="img" aria-label="TOKCONSULT"><path fill="currentColor" style="fill: currentColor" d="M110.2 103.7C107.5 103.6 105.1 103.3 102.5 102.7C99.8 102.2 95.2 100.7 94.7 100.3C94.5 100.2 94.0 100.0 93.6 99.9C93.1 99.8 92.7 99.6 92.6 99.5C92.6 99.4 91.9 99.0 91.1 98.6C88.5 97.3 86.1 95.6 83.0 92.7C79.7 89.7 79.1 89.0 77.3 86.3C76.7 85.4 75.9 84.3 75.6 84.0C75.1 83.3 74.0 81.3 72.8 78.4C72.5 77.8 72.0 76.8 71.7 76.2C71.2 74.9 70.6 73.1 70.1 70.7C69.9 69.7 69.6 68.8 69.5 68.5C69.1 67.8 68.5 62.3 68.3 58.4C68.2 55.7 68.3 53.8 68.7 50.5C69.0 48.2 69.4 46.0 69.5 45.7C69.6 45.5 69.9 44.5 70.1 43.6C70.7 40.9 71.3 38.9 71.7 38.5C71.8 38.3 72.0 37.9 72.0 37.7C72.0 37.5 72.2 37.0 72.5 36.6C72.8 36.1 73.0 35.6 73.0 35.5C73.0 34.5 77.9 26.6 79.7 24.9C82.9 21.6 85.7 19.2 87.6 17.9C90.1 16.2 94.4 14.0 95.0 14.0C95.3 14.0 95.5 13.9 95.6 13.8C95.8 13.5 96.1 13.4 99.1 12.6C103.9 11.2 107.5 10.7 113.1 10.7C120.0 10.7 124.6 11.5 130.9 13.9C132.4 14.4 137.3 16.9 137.9 17.5C138.2 17.7 138.8 18.2 139.4 18.5C140.3 19.0 143.7 22.2 146.3 24.9C146.8 25.4 148.3 27.3 149.5 29.1C151.5 32.2 151.9 32.9 153.2 35.9C153.5 36.5 154.0 37.5 154.2 38.1C154.9 39.6 155.7 41.9 156.0 43.6C156.1 44.4 156.3 45.2 156.5 45.4C157.0 46.5 157.8 53.4 157.8 57.1C157.8 60.9 157.0 67.8 156.5 68.8C156.3 69.1 156.1 69.9 156.0 70.7C155.6 72.9 154.9 74.8 153.4 78.1C153.2 78.5 152.7 79.5 152.4 80.3C152.0 81.0 151.7 81.8 151.7 81.9C151.7 82.0 151.2 82.8 150.6 83.6C150.0 84.5 148.9 86.1 148.1 87.2C145.6 90.8 138.9 96.7 135.1 98.5C134.4 98.9 133.7 99.2 133.5 99.4C133.3 99.5 132.3 100.0 131.2 100.4C130.2 100.7 129.1 101.2 128.8 101.4C128.4 101.6 127.5 101.8 126.7 102.0C125.9 102.1 125.0 102.3 124.8 102.5C124.5 102.6 123.7 102.8 123.0 102.9C122.2 103.0 120.8 103.2 119.8 103.4C117.5 103.8 114.1 103.9 110.2 103.7ZM215.1 103.8C214.8 103.6 213.8 102.6 212.8 101.5C210.2 98.3 203.1 89.5 201.3 87.2C200.4 86.0 199.6 85.1 199.5 85.0C199.4 84.9 196.7 81.6 193.5 77.6C190.3 73.6 187.5 70.3 187.4 70.3C187.2 70.3 186.9 70.3 186.7 70.4C186.4 70.6 183.4 73.9 180.8 76.7C180.4 77.2 177.7 80.3 174.9 83.5C172.0 86.7 169.4 89.7 169.0 90.1C168.7 90.5 167.3 92.1 166.0 93.5C164.7 95.0 163.4 96.5 163.1 96.9C162.6 97.5 162.5 97.6 162.3 97.2C162.1 97.0 162.0 82.8 162.0 54.2L162.0 11.6L162.5 11.1C163.0 10.7 163.6 10.6 170.6 10.6C177.1 10.5 178.3 10.5 179.0 10.9L179.8 11.3L179.8 32.0C179.8 43.4 179.8 52.9 179.9 53.1C180.1 53.7 180.7 53.6 181.3 52.7C182.0 51.7 191.2 40.2 191.7 39.9C191.8 39.7 192.4 39.1 192.9 38.4C193.4 37.7 196.2 34.2 199.1 30.6C202.0 27.1 206.7 21.3 209.5 17.8C212.9 13.7 215.0 11.2 215.5 10.9C216.3 10.5 217.3 10.5 225.6 10.5C235.2 10.5 236.0 10.6 236.2 11.5C236.3 11.8 227.3 23.4 226.5 24.0C226.4 24.1 225.7 24.9 225.0 25.9C224.3 26.8 223.5 27.7 223.4 27.9C223.2 28.0 220.7 31.0 217.9 34.6C215.0 38.2 212.1 41.8 211.4 42.7C210.7 43.5 208.3 46.5 206.0 49.3C203.8 52.1 201.3 55.1 200.6 56.0C199.8 56.8 199.2 57.8 199.2 58.0C199.2 58.3 200.0 59.4 201.0 60.5C201.9 61.5 203.5 63.4 204.5 64.6C205.5 65.9 206.4 66.9 206.5 67.0C206.6 67.1 207.5 68.1 208.5 69.4C209.6 70.6 211.2 72.5 212.0 73.5C212.9 74.5 214.2 76.0 214.9 76.9C216.3 78.6 219.0 81.7 219.4 82.1C219.5 82.3 220.4 83.3 221.4 84.5C222.3 85.7 223.2 86.7 223.4 86.9C223.6 87.1 225.6 89.4 232.0 97.0C236.6 102.4 236.8 102.7 236.7 103.1C236.6 103.3 236.2 103.6 235.9 103.8C235.1 104.1 215.8 104.1 215.1 103.8ZM320.2 103.7C317.7 103.6 315.5 103.5 315.3 103.4C315.1 103.3 313.8 103.1 312.5 103.0C311.2 102.9 309.1 102.6 307.9 102.3C305.8 102.0 304.7 101.7 300.6 100.5C299.6 100.2 298.4 99.9 297.8 99.7C297.2 99.6 296.7 99.4 296.6 99.2C296.5 99.1 296.3 99.0 296.1 99.0C295.7 99.0 293.2 98.0 292.5 97.5C292.3 97.4 292.0 97.2 291.8 97.1C290.9 96.7 287.6 94.7 286.3 93.8C282.0 90.7 277.9 85.9 275.5 81.2C275.2 80.6 274.8 80.0 274.7 79.8C274.6 79.5 274.4 79.2 274.3 79.0C274.3 78.8 274.0 78.2 273.7 77.6C273.3 76.7 272.5 73.9 271.7 70.9C271.4 70.0 271.1 68.5 271.0 67.4C270.9 66.3 270.6 64.6 270.5 63.8C270.2 61.6 270.2 53.2 270.5 50.6C270.6 49.5 270.9 47.7 271.0 46.6C271.2 44.6 271.6 43.0 272.5 40.1C272.8 39.3 273.0 38.5 273.0 38.3C273.0 38.1 273.3 37.3 273.7 36.5C274.0 35.8 274.5 34.6 274.8 34.0C275.1 33.4 275.4 32.7 275.5 32.5C277.8 28.7 278.5 27.6 280.2 25.7C283.0 22.5 287.1 19.2 290.5 17.5C291.4 17.1 292.3 16.6 292.5 16.5C293.6 15.9 297.7 14.3 298.8 14.1C299.2 14.0 300.3 13.7 301.1 13.5C303.4 12.8 304.8 12.5 306.1 12.2C313.1 11.0 316.2 10.8 329.9 10.6C339.4 10.4 339.9 10.5 340.4 10.9L341.0 11.4L341.0 29.4C341.0 39.4 341.0 47.6 340.9 47.8C340.7 48.1 324.1 48.1 323.9 47.7C323.8 47.6 323.7 43.2 323.7 37.9C323.8 26.2 324.1 27.3 319.9 27.2C315.6 27.2 307.2 28.6 306.1 29.5C306.0 29.6 305.4 29.8 304.9 29.9C304.4 30.0 303.1 30.6 302.0 31.2C300.9 31.9 299.6 32.6 299.1 32.8C297.9 33.4 293.4 37.9 292.9 39.0C292.7 39.5 292.0 40.7 291.4 41.8C290.7 42.8 290.2 43.9 290.1 44.2C290.0 44.6 289.8 45.4 289.6 46.0C288.5 49.2 288.2 51.4 288.1 56.7C288.0 61.0 288.0 62.3 288.3 63.7C288.6 64.6 288.8 65.9 289.0 66.6C289.2 68.0 289.9 70.0 290.4 71.1C290.6 71.5 290.9 72.2 291.0 72.5C291.8 74.4 294.0 77.5 295.7 79.1C297.3 80.5 300.6 82.8 301.6 83.1C301.9 83.2 302.3 83.5 302.6 83.7C302.9 83.8 303.3 84.0 303.5 84.0C303.7 84.0 304.3 84.2 304.9 84.5C306.8 85.4 310.4 86.2 314.8 86.8C315.6 86.9 321.9 87.0 328.5 87.0C336.9 87.0 340.8 87.1 340.9 87.3C341.1 87.6 341.1 102.8 340.9 103.3C340.8 103.5 340.5 103.8 340.2 103.8C339.4 104.0 325.6 104.0 320.2 103.7ZM387.2 103.7C384.5 103.6 382.1 103.3 379.5 102.7C376.8 102.2 372.2 100.7 371.7 100.3C371.5 100.2 371.0 100.0 370.6 99.9C370.1 99.8 369.7 99.6 369.6 99.5C369.6 99.4 368.9 99.0 368.1 98.6C365.4 97.3 363.1 95.6 359.7 92.4C357.3 90.1 355.9 88.6 354.9 87.2C354.2 86.0 353.2 84.7 352.8 84.2C352.1 83.3 351.1 81.4 349.8 78.4C349.5 77.8 349.0 76.7 348.7 76.1C348.2 74.9 348.0 74.4 347.4 71.8C347.2 70.9 346.8 69.6 346.6 68.9C345.9 66.6 345.2 59.7 345.3 55.9C345.5 52.0 346.1 46.5 346.5 45.7C346.6 45.5 346.9 44.5 347.1 43.6C347.8 40.1 348.2 39.0 350.5 34.4C350.8 33.8 351.0 33.3 351.0 33.2C351.0 32.7 355.7 25.9 356.7 24.9C359.9 21.6 362.7 19.2 364.6 17.9C367.1 16.2 371.4 14.0 372.0 14.0C372.3 14.0 372.5 13.9 372.6 13.8C372.8 13.5 373.1 13.4 376.1 12.6C381.8 10.9 387.5 10.4 394.5 10.9C399.5 11.2 402.7 12.0 407.9 13.9C409.4 14.4 414.3 16.9 414.9 17.5C415.1 17.7 415.8 18.2 416.4 18.5C417.3 19.0 420.6 22.1 423.3 24.9C423.9 25.4 424.8 26.6 425.4 27.5C426.0 28.4 426.9 29.8 427.5 30.6C428.5 32.0 428.9 32.9 430.3 35.9C430.5 36.5 431.0 37.5 431.2 38.1C431.9 39.6 432.7 41.9 433.0 43.6C433.1 44.4 433.3 45.2 433.5 45.4C434.0 46.5 434.8 53.4 434.8 57.1C434.8 60.8 434.0 67.8 433.5 68.8C433.3 69.1 433.1 69.9 433.0 70.7C432.7 72.3 431.9 74.6 431.2 76.2C431.0 76.8 430.5 77.8 430.2 78.4C430.0 79.0 429.5 80.0 429.2 80.6C429.0 81.2 428.7 81.8 428.7 81.9C428.7 82.0 428.2 82.8 427.6 83.6C427.0 84.5 425.9 86.1 425.1 87.2C422.6 90.8 415.9 96.7 412.1 98.5C411.4 98.9 410.7 99.2 410.5 99.4C409.8 99.9 404.9 101.7 403.6 102.0C402.8 102.1 402.0 102.3 401.8 102.5C401.5 102.6 400.7 102.8 400.0 102.9C399.2 103.0 397.8 103.2 396.8 103.4C394.5 103.8 391.1 103.9 387.2 103.7ZM501.3 103.6C501.0 103.4 500.2 102.5 499.6 101.5C499.0 100.6 497.5 98.5 496.4 96.9C495.2 95.2 493.7 93.0 492.9 91.9C492.1 90.8 490.4 88.4 489.1 86.5C487.8 84.6 486.0 82.1 485.1 80.8C484.2 79.4 482.6 77.2 481.6 75.8C480.6 74.3 478.8 71.7 477.6 70.0C476.4 68.3 475.0 66.2 474.4 65.4C473.1 63.6 471.3 61.0 469.7 58.6C468.6 57.1 467.5 55.5 464.7 51.5C464.3 50.9 463.4 49.6 462.7 48.6C462.0 47.7 461.0 46.2 460.4 45.4C459.9 44.5 459.3 43.6 459.1 43.4C458.9 43.1 458.6 42.9 458.3 42.9C457.9 42.9 457.9 43.4 457.8 61.9C457.8 72.3 457.7 80.9 457.5 81.1C457.4 81.2 453.5 81.3 448.9 81.3C440.9 81.3 440.4 81.3 440.2 80.8C440.0 80.2 440.0 11.7 440.2 11.3C440.3 11.2 440.7 10.9 441.1 10.8C442.0 10.4 456.2 10.4 457.1 10.7C457.7 11.0 458.3 11.8 461.9 16.9C463.0 18.5 464.6 20.8 465.4 21.9C466.1 23.0 467.7 25.2 468.9 26.9C470.0 28.5 471.6 30.8 472.4 31.9C473.1 33.0 474.7 35.2 475.9 36.9C477.0 38.5 478.6 40.8 479.4 41.9C480.1 43.0 481.7 45.2 482.9 46.9C484.0 48.5 485.6 50.8 486.4 51.9C487.1 53.0 488.7 55.2 489.9 56.9C491.0 58.5 492.6 60.8 493.4 61.9C495.7 65.2 499.9 71.2 500.2 71.7C501.0 73.0 501.0 71.9 501.0 41.6C501.0 25.1 501.1 11.5 501.2 11.3C501.6 10.6 502.9 10.5 509.9 10.5C517.4 10.5 518.2 10.6 518.6 11.6C518.7 11.9 518.8 32.3 518.8 57.2C518.8 106.0 518.8 103.5 517.4 103.8C517.1 103.9 513.5 104.0 509.4 104.0C503.0 104.0 501.8 103.9 501.3 103.6ZM551.3 103.7C551.0 103.3 550.9 88.0 551.2 87.5C551.4 87.3 552.1 87.1 553.2 87.0C556.1 86.6 559.3 84.9 561.1 82.4C562.1 81.1 563.0 78.4 563.0 76.7C563.0 75.1 562.3 72.9 561.4 71.2C560.1 69.0 556.1 66.2 553.9 65.9C553.2 65.8 552.5 65.6 552.2 65.5C552.0 65.4 550.4 65.2 548.7 65.0C547.0 64.9 545.0 64.6 544.4 64.4C543.7 64.2 542.7 63.9 542.1 63.8C537.7 62.7 532.8 60.0 529.7 57.0C528.2 55.7 526.3 53.2 525.5 51.6C525.1 50.8 524.6 50.0 524.5 49.9C524.2 49.5 523.5 47.3 523.2 46.0C523.1 45.4 522.8 44.2 522.6 43.5C521.9 41.0 522.6 31.2 523.5 30.1C523.6 30.0 523.9 29.3 524.0 28.6C524.3 27.4 524.7 26.5 526.4 23.7C528.5 20.2 532.9 16.2 536.7 14.3C539.8 12.7 540.8 12.3 541.8 12.1C542.2 12.0 543.3 11.7 544.1 11.4C545.5 11.0 546.2 10.9 551.2 10.9C556.2 10.9 557.1 11.0 558.5 11.4C559.4 11.7 560.5 12.0 561.0 12.1C561.5 12.2 562.8 12.7 563.9 13.3C565.1 13.8 566.1 14.3 566.2 14.3C566.3 14.3 567.0 14.8 567.9 15.4C568.7 16.0 569.8 16.8 570.2 17.1C572.7 18.7 577.0 24.9 577.9 27.9C578.1 28.6 578.4 29.6 578.6 30.2C578.8 30.9 579.1 32.7 579.3 34.2C579.7 38.3 580.3 38.0 571.1 38.0C564.4 38.0 563.7 38.0 563.3 37.6C563.1 37.3 562.7 36.2 562.4 35.1C561.4 30.9 558.5 28.4 553.4 27.4C551.3 27.0 551.2 27.0 548.7 27.5C545.0 28.3 543.3 29.3 541.4 32.0C539.4 34.8 538.8 37.9 539.6 41.1C540.3 43.7 542.3 46.3 544.1 47.0C544.5 47.2 545.0 47.5 545.2 47.6C546.0 48.3 548.5 48.8 551.7 49.0C553.5 49.1 555.6 49.4 556.3 49.6C557.0 49.8 558.2 50.0 558.9 50.1C559.7 50.2 560.3 50.4 560.4 50.5C560.5 50.6 561.0 50.9 561.6 51.0C562.7 51.3 563.4 51.6 565.7 52.7C568.8 54.2 572.2 56.9 574.5 59.8C575.7 61.4 578.0 65.4 578.0 66.0C578.0 66.2 578.2 66.9 578.5 67.6C579.7 71.0 580.2 75.2 579.8 79.4C579.1 85.9 577.0 90.6 573.0 94.9C572.1 95.8 571.0 96.9 570.5 97.3C568.3 98.9 567.0 99.7 565.6 100.4C564.8 100.8 563.8 101.2 563.4 101.4C562.1 102.1 558.2 103.1 555.1 103.5C554.2 103.6 553.0 103.8 552.5 103.9C551.9 103.9 551.5 103.9 551.3 103.7ZM658.1 103.7C657.7 103.6 657.4 103.2 657.2 102.9C656.9 102.0 656.9 87.9 657.3 87.2C657.5 86.8 658.1 86.8 682.4 86.8C702.0 86.8 707.5 86.8 708.0 87.1L708.6 87.4L708.7 95.2C708.8 102.8 708.7 102.9 708.2 103.4C707.7 103.9 707.0 103.9 683.2 103.9C668.7 104.0 658.4 103.9 658.1 103.7ZM611.5 103.3C609.8 103.0 608.0 102.6 607.4 102.4C606.9 102.2 606.2 102.0 605.8 102.0C605.5 102.0 604.6 101.8 604.0 101.5C603.4 101.2 602.4 100.8 601.9 100.5C598.4 99.0 597.3 98.4 594.7 96.4C592.5 94.8 588.0 90.0 588.0 89.2C588.0 89.1 587.7 88.5 587.3 87.9C586.4 86.7 585.0 83.5 585.0 82.9C585.0 82.7 584.8 82.1 584.6 81.7C584.4 81.3 584.0 79.6 583.7 77.9C583.2 75.0 583.2 73.9 583.1 51.9C583.0 36.5 583.1 28.6 583.2 28.2L583.5 27.5L591.7 27.5C597.7 27.5 600.0 27.6 600.2 27.8C600.4 28.0 600.5 33.3 600.5 50.1C600.5 64.7 600.6 72.6 600.8 73.7C601.5 77.9 603.8 81.4 607.7 84.1C608.4 84.6 609.1 85.0 609.3 85.0C609.4 85.0 609.9 85.2 610.3 85.4C612.8 86.7 618.6 87.4 621.5 86.7C622.1 86.6 623.2 86.4 623.9 86.2C626.2 85.7 629.5 84.1 631.4 82.4C633.7 80.2 634.8 78.2 635.4 75.1C635.7 73.2 635.7 68.7 635.7 42.2C635.7 16.2 635.8 11.5 636.1 11.1C636.4 10.6 636.8 10.6 644.3 10.6C650.6 10.6 652.3 10.7 652.6 11.0C653.0 11.3 653.0 13.8 653.0 42.6C653.0 61.4 652.9 74.8 652.7 76.2C652.5 78.9 651.9 81.8 651.3 82.8C651.2 83.2 651.0 83.7 651.0 84.0C651.0 84.4 649.0 88.5 648.4 89.2C648.2 89.5 648.0 89.9 647.8 90.2C647.3 91.4 643.0 95.7 640.8 97.2C637.9 99.2 636.0 100.1 632.5 101.4C627.0 103.5 618.0 104.3 611.5 103.3ZM116.0 87.5C120.0 87.0 121.6 86.6 124.5 85.3C125.5 84.9 125.4 85.0 127.9 83.5C131.0 81.5 136.0 75.9 137.0 73.1C137.3 72.2 138.2 70.4 138.6 69.5C138.8 69.2 139.0 68.4 139.1 67.9C139.2 67.3 139.4 66.4 139.6 65.8C139.8 65.1 140.2 63.0 140.4 61.0C140.7 58.1 140.7 56.8 140.5 54.8C140.0 50.3 139.3 47.0 138.5 45.1C138.3 44.6 137.8 43.5 137.5 42.6C136.6 40.5 134.0 36.7 131.9 34.5C130.1 32.6 126.9 30.3 125.0 29.4C121.8 28.0 119.1 27.3 116.0 27.0C112.2 26.7 107.9 27.1 105.5 27.9C104.5 28.3 103.2 28.7 102.6 28.8C101.3 29.2 100.9 29.5 97.9 31.4C96.6 32.3 94.8 33.8 94.0 34.6C92.3 36.5 89.4 40.8 88.9 42.2C88.7 42.7 88.4 43.4 88.3 43.7C87.7 44.8 87.0 46.7 86.9 47.6C86.8 48.2 86.6 49.1 86.4 49.8C85.5 52.6 85.5 62.2 86.4 65.0C86.6 65.6 86.8 66.6 86.9 67.2C87.0 67.9 87.3 68.8 87.5 69.2C87.8 69.7 88.0 70.3 88.0 70.5C88.0 70.8 88.1 71.0 88.2 71.1C88.4 71.2 88.6 71.8 88.8 72.4C89.5 74.3 92.3 78.2 94.7 80.5C98.2 83.9 102.9 86.4 107.1 87.0C108.0 87.1 109.3 87.3 110.1 87.5C112.3 87.8 113.6 87.8 116.0 87.5ZM393.0 87.5C397.2 87.0 398.4 86.7 401.2 85.4C402.5 84.9 402.4 85.0 404.9 83.5C408.0 81.5 413.0 75.9 414.0 73.1C414.2 72.7 414.5 71.9 414.8 71.2C415.1 70.6 415.4 69.8 415.6 69.4C416.3 67.8 417.0 64.2 417.5 60.0C417.9 55.7 416.9 48.3 415.5 45.1C415.3 44.6 414.8 43.5 414.5 42.6C413.6 40.5 411.0 36.7 408.9 34.5C407.2 32.7 403.2 29.7 402.6 29.7C402.4 29.8 402.2 29.6 402.0 29.4C401.8 29.2 401.5 29.0 401.2 29.0C400.9 29.0 400.2 28.8 399.5 28.5C397.3 27.6 395.7 27.2 393.0 27.0C389.2 26.7 384.9 27.1 382.5 27.9C381.5 28.3 380.2 28.7 379.6 28.8C378.3 29.2 377.9 29.5 374.9 31.4C373.6 32.3 371.8 33.8 371.0 34.6C369.5 36.3 366.4 40.7 366.0 41.9C365.9 42.3 365.6 43.0 365.4 43.4C364.5 45.3 364.0 46.7 363.9 47.6C363.8 48.2 363.6 49.1 363.4 49.8C362.5 52.6 362.5 62.2 363.4 65.0C363.6 65.6 363.8 66.6 363.9 67.2C364.0 67.9 364.3 68.8 364.5 69.2C364.8 69.7 365.0 70.3 365.0 70.5C365.0 70.8 365.1 71.0 365.2 71.1C365.4 71.2 365.6 71.8 365.8 72.4C366.5 74.3 369.3 78.2 371.7 80.5C375.2 83.9 379.9 86.4 384.1 87.0C384.9 87.1 386.3 87.3 387.1 87.5C389.3 87.8 390.6 87.8 393.0 87.5ZM657.4 68.4C657.2 68.3 657.1 61.0 657.1 39.9L657.0 11.6L657.5 11.1C658.0 10.7 658.6 10.6 665.6 10.6C672.1 10.5 673.3 10.5 674.0 10.9L674.8 11.3L674.8 39.8C674.8 62.3 674.7 68.3 674.4 68.4C673.9 68.6 657.7 68.6 657.4 68.4ZM111.5 65.8C110.0 65.6 107.7 64.3 106.8 63.2C105.8 62.1 105.1 60.7 104.8 59.3C103.8 54.5 106.9 49.7 111.5 49.0C113.5 48.8 116.1 49.1 117.1 49.8C119.3 51.4 121.0 53.4 121.0 54.4C121.0 54.7 121.2 55.5 121.4 56.2C121.7 57.3 121.7 57.6 121.3 59.3C120.5 62.3 119.0 64.1 116.4 65.3C115.3 65.8 112.7 66.1 111.5 65.8ZM388.5 65.8C387.0 65.6 384.7 64.3 383.7 63.1C382.2 61.4 381.2 57.8 381.7 56.2C381.9 55.8 382.0 55.1 382.0 54.8C382.0 54.1 383.4 51.9 384.4 51.0C386.3 49.3 388.6 48.7 391.7 49.1C393.2 49.3 394.1 49.7 395.7 51.0C396.7 51.9 398.0 53.8 398.0 54.4C398.0 54.7 398.2 55.5 398.4 56.2C398.7 57.3 398.7 57.6 398.3 59.3C397.5 62.3 396.0 64.1 393.4 65.3C392.3 65.8 389.7 66.1 388.5 65.8ZM9.0 26.1C8.1 25.7 8.0 25.3 8.0 18.4C8.0 11.8 8.0 11.6 8.5 11.1C9.0 10.6 9.9 10.6 35.8 10.6C57.1 10.5 62.8 10.6 63.2 10.8L63.9 11.1L63.9 18.4C64.0 25.0 64.0 25.7 63.6 25.9C63.2 26.2 57.4 26.2 36.3 26.2C21.5 26.2 9.2 26.2 9.0 26.1ZM712.0 26.1C711.1 25.7 711.0 25.3 711.0 18.4C711.0 11.8 711.0 11.6 711.5 11.1C712.0 10.6 712.9 10.6 738.8 10.6C760.1 10.5 765.8 10.6 766.2 10.8L766.9 11.1L766.9 18.4C767.0 25.0 767.0 25.7 766.6 25.9C766.2 26.2 760.4 26.2 739.3 26.2C724.5 26.2 712.2 26.2 712.0 26.1Z"/><path fill="#E75A4E" style="fill: #E75A4E" d="M26.2 106.3C26.0 105.6 26.0 36.7 26.2 36.2C26.4 35.7 26.6 35.7 36.9 35.7C42.6 35.7 47.4 35.8 47.5 35.9C47.7 36.1 47.7 52.0 47.7 71.4L47.6 106.6L37.0 106.7C27.0 106.8 26.3 106.7 26.2 106.3ZM729.2 106.3C729.0 105.6 729.0 36.7 729.2 36.2C729.4 35.7 729.8 35.7 739.7 35.7C748.0 35.7 750.1 35.8 750.3 36.0C750.4 36.2 750.5 52.2 750.4 71.5L750.4 106.6L739.8 106.7C729.9 106.8 729.3 106.7 729.2 106.3Z"/></svg>';

	const CSS = <<<'TOKHCSS'
.entry-content #tok-site,#tok-site>.tk,#tok-site>*{max-width:none!important;width:auto!important;margin-left:0!important;margin-right:0!important}#masthead,.site-header,header.site-header,#ast-desktop-header,#ast-mobile-header,.ast-mobile-header-wrap{display:none!important}html.tokh-lock,html.tokh-lock body{overflow:hidden!important}#tokh{position:fixed!important;top:var(--wp-admin--admin-bar--height,0px)!important;left:0!important;right:0!important;width:100%!important;z-index:100000!important;background:#FFFFFF!important;border-bottom:1px solid #E1E5EC!important;font-family:'DM Sans',system-ui,-apple-system,'Segoe UI',sans-serif!important;color:#121B32!important;font-size:16px!important;line-height:1.4!important;transition:box-shadow .2s ease!important;margin:0!important;padding:0!important;text-align:left!important}#tokh.tokh-scrolled{box-shadow:0 8px 24px rgba(18,27,50,0.08)!important}#tokh *{box-sizing:border-box!important}#tokh a{text-decoration:none!important;color:#121B32!important;box-shadow:none!important;border:0!important;background:none!important;font-family:inherit!important;text-transform:none!important;letter-spacing:normal!important}#tokh button{font-family:inherit!important;text-transform:none!important;letter-spacing:normal!important;margin:0!important;box-shadow:none!important;line-height:1.4!important}#tokh ul{list-style:none!important;margin:0!important;padding:0!important}#tokh li{margin:0!important;padding:0!important;list-style:none!important}#tokh li::before,#tokh li::marker{content:none!important}#tokh p{margin:0!important;padding:0!important}#tokh-space{display:block!important;height:77px!important}#tokh .tokh-in{max-width:1280px!important;margin:0 auto!important;padding:0 32px!important;height:76px!important;display:flex!important;align-items:center!important;gap:24px!important}#tokh .tokh-logo{display:inline-flex!important;align-items:center!important;flex:none!important;min-height:44px!important;color:#121B32!important}#tokh .tokh-logo svg{width:150px!important;height:auto!important;display:block!important;color:#121B32!important}#tokh .tokh-nav{flex:1!important;display:flex!important;justify-content:center!important}#tokh .tokh-menu{display:flex!important;align-items:center!important;gap:4px!important}#tokh .tokh-item{position:relative!important}#tokh .tokh-link{display:inline-flex!important;align-items:center!important;gap:6px!important;min-height:44px!important;padding:0 14px!important;border-radius:10px!important;font-size:15.5px!important;font-weight:500!important;color:#121B32!important;background:none!important;border:0!important;cursor:pointer!important}#tokh .tokh-link:hover,#tokh .tokh-item.tokh-open>.tokh-link{background:#F5F6F8!important;color:#121B32!important}#tokh .tokh-link.tokh-active{font-weight:700!important;color:#C8402F!important}#tokh .tokh-link:focus-visible,#tokh .tokh-cta:focus-visible,#tokh .tokh-burger:focus-visible,#tokh .tokh-card:focus-visible,#tokh .tokh-m-link:focus-visible{outline:3px solid #E75A4E!important;outline-offset:2px!important}#tokh .tokh-chev{width:14px!important;height:14px!important;transition:transform .2s ease!important;flex:none!important}#tokh .tokh-item.tokh-open .tokh-chev{transform:rotate(180deg)!important}#tokh .tokh-panel{position:absolute!important;top:calc(100% + 10px)!important;left:50%!important;transform:translate(-50%,6px)!important;background:#FFFFFF!important;border:1px solid #E1E5EC!important;border-radius:18px!important;box-shadow:0 24px 60px rgba(18,27,50,0.16)!important;padding:20px!important;opacity:0!important;visibility:hidden!important;pointer-events:none!important;transition:opacity .18s ease,transform .18s ease,visibility 0s linear .18s!important;z-index:9991!important}#tokh .tokh-panel::before{content:""!important;position:absolute!important;left:0!important;right:0!important;top:-12px!important;height:12px!important}#tokh .tokh-item.tokh-open>.tokh-panel{opacity:1!important;visibility:visible!important;pointer-events:auto!important;transform:translate(-50%,0)!important;transition:opacity .18s ease,transform .18s ease,visibility 0s!important}#tokh .tokh-panel-svc{width:720px!important}#tokh .tokh-panel-res{width:420px!important}#tokh .tokh-grid{display:grid!important;grid-template-columns:1fr 1fr!important;gap:6px!important}#tokh .tokh-panel-res .tokh-grid{grid-template-columns:1fr!important}#tokh .tokh-card{display:flex!important;gap:14px!important;align-items:flex-start!important;padding:14px!important;border-radius:12px!important;color:#121B32!important}#tokh .tokh-card:hover{background:#F5F6F8!important}#tokh .tokh-card.tokh-active{background:#FDF1EF!important}#tokh .tokh-ico{width:40px!important;height:40px!important;border-radius:12px!important;background:#FDF1EF!important;color:#C8402F!important;display:flex!important;align-items:center!important;justify-content:center!important;flex:none!important}#tokh .tokh-ico svg{width:22px!important;height:22px!important}#tokh .tokh-card-t{display:flex!important;flex-direction:column!important;gap:3px!important}#tokh .tokh-card-t strong{font-family:Sora,'DM Sans',sans-serif!important;font-size:15px!important;font-weight:700!important;color:#121B32!important;letter-spacing:-0.01em!important}#tokh .tokh-card-t span{font-size:13.5px!important;color:#4A5266!important;line-height:1.45!important}#tokh .tokh-foot{display:flex!important;flex-wrap:wrap!important;justify-content:space-between!important;align-items:center!important;gap:10px!important;margin-top:12px!important;padding:14px 14px 2px!important;border-top:1px solid #E1E5EC!important;font-size:14px!important;color:#4A5266!important}#tokh .tokh-foot a{font-weight:700!important;color:#C8402F!important;min-height:36px!important;display:inline-flex!important;align-items:center!important}#tokh .tokh-right{display:flex!important;align-items:center!important;gap:10px!important;flex:none!important}#tokh .tokh-cta{display:inline-flex!important;align-items:center!important;justify-content:center!important;min-height:46px!important;padding:0 20px!important;border-radius:10px!important;background:#D4463A!important;color:#FFFFFF!important;font-weight:700!important;font-size:15px!important;white-space:nowrap!important}#tokh .tokh-cta:hover{background:#B93A2F!important;color:#FFFFFF!important}#tokh .tokh-burger{display:none!important;width:48px!important;height:48px!important;border-radius:12px!important;border:1px solid #E1E5EC!important;background:#FFFFFF!important;cursor:pointer!important;align-items:center!important;justify-content:center!important;padding:0!important;color:#121B32!important}#tokh .tokh-burger span{display:block!important;width:20px!important;height:2px!important;background:#121B32!important;border-radius:2px!important;position:relative!important;transition:background .2s ease!important}#tokh .tokh-burger span::before,#tokh .tokh-burger span::after{content:""!important;position:absolute!important;left:0!important;width:20px!important;height:2px!important;background:#121B32!important;border-radius:2px!important;transition:transform .2s ease,top .2s ease!important}#tokh .tokh-burger span::before{top:-6px!important}#tokh .tokh-burger span::after{top:6px!important}#tokh.tokh-m-open .tokh-burger span{background:transparent!important}#tokh.tokh-m-open .tokh-burger span::before{top:0!important;transform:rotate(45deg)!important}#tokh.tokh-m-open .tokh-burger span::after{top:0!important;transform:rotate(-45deg)!important}#tokh .tokh-mobile{display:none!important}@media (max-width:1080px){#tokh-space{height:69px!important}#tokh .tokh-in{height:68px!important;padding:0 20px!important;gap:12px!important}#tokh .tokh-logo svg{width:132px!important}#tokh .tokh-nav{display:none!important}#tokh .tokh-right{margin-left:auto!important}#tokh .tokh-burger{display:inline-flex!important}#tokh .tokh-mobile{display:block!important;position:fixed!important;left:0!important;right:0!important;top:calc(68px + var(--wp-admin--admin-bar--height,0px))!important;bottom:0!important;background:#FFFFFF!important;overflow-y:auto!important;-webkit-overflow-scrolling:touch!important;padding:12px 20px 32px!important;transform:translateX(100%)!important;visibility:hidden!important;transition:transform .25s ease,visibility 0s linear .25s!important;z-index:9989!important;border-top:1px solid #E1E5EC!important}#tokh.tokh-m-open .tokh-mobile{transform:translateX(0)!important;visibility:visible!important;transition:transform .25s ease,visibility 0s!important}#tokh .tokh-m-list>li{border-bottom:1px solid #E1E5EC!important}#tokh .tokh-m-link{display:flex!important;width:100%!important;align-items:center!important;justify-content:space-between!important;min-height:60px!important;padding:0 4px!important;font-family:Sora,'DM Sans',sans-serif!important;font-size:19px!important;font-weight:700!important;color:#121B32!important;background:none!important;border:0!important;cursor:pointer!important;text-align:left!important}#tokh .tokh-m-link.tokh-active{color:#C8402F!important}#tokh .tokh-m-link .tokh-chev{width:18px!important;height:18px!important}#tokh .tokh-m-item.tokh-open .tokh-chev{transform:rotate(180deg)!important}#tokh .tokh-m-sub{display:none!important;padding:0 0 14px!important}#tokh .tokh-m-item.tokh-open .tokh-m-sub{display:block!important}#tokh .tokh-m-sub a{display:flex!important;align-items:center!important;gap:12px!important;min-height:52px!important;padding:8px 6px!important;border-radius:12px!important;font-size:16px!important;font-weight:500!important;color:#3A4257!important}#tokh .tokh-m-sub a.tokh-active{background:#FDF1EF!important;color:#C8402F!important;font-weight:700!important}#tokh .tokh-m-sub .tokh-ico{width:34px!important;height:34px!important;border-radius:10px!important}#tokh .tokh-m-sub .tokh-ico svg{width:18px!important;height:18px!important}#tokh .tokh-m-ctas{display:flex!important;flex-direction:column!important;gap:10px!important;margin-top:24px!important}#tokh .tokh-m-ctas .tokh-cta{min-height:54px!important;font-size:16px!important}#tokh .tokh-wa{display:inline-flex!important;align-items:center!important;justify-content:center!important;gap:10px!important;min-height:54px!important;border-radius:10px!important;background:#128C4A!important;color:#FFFFFF!important;font-weight:700!important;font-size:16px!important}#tokh .tokh-wa:hover{background:#0E7A40!important;color:#FFFFFF!important}#tokh .tokh-m-note{margin-top:18px!important;font-size:14px!important;color:#4A5266!important;text-align:center!important}}@media (max-width:480px){#tokh .tokh-right .tokh-cta{display:none!important}}@media (prefers-reduced-motion:reduce){#tokh *,#tokh{transition:none!important}}
TOKHCSS;

	const JS = <<<'TOKHJS'
(function(){
var h=document.getElementById('tokh');if(!h)return;
var desk=window.matchMedia('(min-width:1081px)');
var items=[].slice.call(h.querySelectorAll('.tokh-item.tokh-has'));
function closeAll(except){items.forEach(function(it){if(it!==except){it.classList.remove('tokh-open');var b=it.querySelector('.tokh-link');if(b)b.setAttribute('aria-expanded','false');}});}
items.forEach(function(it){
  var btn=it.querySelector('.tokh-link'),t;
  btn.addEventListener('click',function(e){e.preventDefault();var open=!it.classList.contains('tokh-open');closeAll(it);it.classList.toggle('tokh-open',open);btn.setAttribute('aria-expanded',open?'true':'false');});
  it.addEventListener('mouseenter',function(){if(!desk.matches)return;clearTimeout(t);closeAll(it);it.classList.add('tokh-open');btn.setAttribute('aria-expanded','true');});
  it.addEventListener('mouseleave',function(){if(!desk.matches)return;t=setTimeout(function(){it.classList.remove('tokh-open');btn.setAttribute('aria-expanded','false');},180);});
});
document.addEventListener('click',function(e){if(!h.contains(e.target))closeAll();});
var burger=h.querySelector('.tokh-burger'),panel=h.querySelector('.tokh-mobile');
function setMobile(open){h.classList.toggle('tokh-m-open',open);document.documentElement.classList.toggle('tokh-lock',open);burger.setAttribute('aria-expanded',open?'true':'false');burger.setAttribute('aria-label',open?'Close menu':'Open menu');if(panel){panel.setAttribute('aria-hidden',open?'false':'true');}}
if(burger){burger.addEventListener('click',function(){setMobile(!h.classList.contains('tokh-m-open'));});}
[].slice.call(h.querySelectorAll('.tokh-m-item.tokh-has>.tokh-m-link')).forEach(function(b){b.addEventListener('click',function(){var it=b.parentNode,open=!it.classList.contains('tokh-open');it.classList.toggle('tokh-open',open);b.setAttribute('aria-expanded',open?'true':'false');});});
if(panel){[].slice.call(panel.querySelectorAll('a')).forEach(function(a){a.addEventListener('click',function(){setMobile(false);});});}
document.addEventListener('keydown',function(e){if(e.key==='Escape'){closeAll();if(h.classList.contains('tokh-m-open')){setMobile(false);burger.focus();}}});
desk.addEventListener?desk.addEventListener('change',function(){setMobile(false);closeAll();}):0;
function onScroll(){h.classList.toggle('tokh-scrolled',window.scrollY>4);}
window.addEventListener('scroll',onScroll,{passive:true});onScroll();
})();
TOKHJS;
}

TOKH_Header::init();
