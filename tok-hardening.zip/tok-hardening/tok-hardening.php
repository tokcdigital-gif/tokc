<?php
/**
 * Plugin Name:       TOKCONSULT Hardening
 * Description:       Closes common WordPress weak spots: turns off comments site-wide, XML-RPC, the dashboard code editor, username discovery and version leaks, and adds browser security headers. No settings. Works alongside Wordfence.
 * Version:           1.0.0
 * Author:            TOKCONSULT
 * Requires at least: 6.0
 * Requires PHP:      7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Stop anyone who gets into the dashboard from editing theme or plugin code there.
if ( ! defined( 'DISALLOW_FILE_EDIT' ) ) {
	define( 'DISALLOW_FILE_EDIT', true );
}

final class TOKH {

	public static function init() {
		/* --- Comments and pingbacks: off everywhere --- */
		add_action( 'init', array( __CLASS__, 'remove_comment_support' ), 100 );
		add_filter( 'comments_open', '__return_false', 20 );
		add_filter( 'pings_open', '__return_false', 20 );
		add_filter( 'comments_array', '__return_empty_array', 20 );
		add_filter( 'get_comments_number', '__return_zero', 20 );
		add_action( 'pre_comment_on_post', array( __CLASS__, 'block_comment_post' ) );
		add_filter( 'rest_allow_anonymous_comments', '__return_false' );
		add_filter( 'feed_links_show_comments_feed', '__return_false' );
		add_action( 'admin_menu', array( __CLASS__, 'admin_menu' ), 999 );
		add_action( 'admin_init', array( __CLASS__, 'admin_redirect' ) );
		add_action( 'wp_before_admin_bar_render', array( __CLASS__, 'admin_bar' ) );
		add_action( 'wp_dashboard_setup', array( __CLASS__, 'dashboard' ) );

		/* --- XML-RPC: off --- */
		add_filter( 'xmlrpc_enabled', '__return_false' );
		add_filter( 'xmlrpc_methods', '__return_empty_array' );
		add_filter( 'wp_headers', array( __CLASS__, 'strip_pingback_header' ) );
		remove_action( 'wp_head', 'rsd_link' );

		/* --- Don't advertise the WordPress version --- */
		remove_action( 'wp_head', 'wp_generator' );
		add_filter( 'the_generator', '__return_empty_string' );
		add_filter( 'style_loader_src', array( __CLASS__, 'strip_core_version' ), 99 );
		add_filter( 'script_loader_src', array( __CLASS__, 'strip_core_version' ), 99 );

		/* --- Don't reveal usernames --- */
		add_action( 'template_redirect', array( __CLASS__, 'block_author_scan' ), 1 );
		add_filter( 'rest_endpoints', array( __CLASS__, 'rest_endpoints' ) );
		add_filter( 'login_errors', array( __CLASS__, 'login_error' ) );
		add_filter( 'oembed_response_data', array( __CLASS__, 'oembed_author' ) );

		/* --- Browser security headers --- */
		add_action( 'send_headers', array( __CLASS__, 'headers' ) );
	}

	/* ---------- comments ---------- */

	public static function remove_comment_support() {
		foreach ( get_post_types() as $type ) {
			if ( post_type_supports( $type, 'comments' ) ) {
				remove_post_type_support( $type, 'comments' );
				remove_post_type_support( $type, 'trackbacks' );
			}
		}
	}

	public static function block_comment_post() {
		wp_die( esc_html__( 'Comments are closed on this site.' ), '', array( 'response' => 403 ) );
	}

	public static function admin_menu() {
		remove_menu_page( 'edit-comments.php' );
		remove_submenu_page( 'options-general.php', 'options-discussion.php' );
	}

	public static function admin_redirect() {
		global $pagenow;
		if ( in_array( $pagenow, array( 'edit-comments.php', 'comment.php', 'options-discussion.php' ), true ) ) {
			wp_safe_redirect( admin_url() );
			exit;
		}
	}

	public static function admin_bar() {
		global $wp_admin_bar;
		if ( $wp_admin_bar ) {
			$wp_admin_bar->remove_menu( 'comments' );
		}
	}

	public static function dashboard() {
		remove_meta_box( 'dashboard_recent_comments', 'dashboard', 'normal' );
	}

	/* ---------- xml-rpc / version ---------- */

	public static function strip_pingback_header( $headers ) {
		unset( $headers['X-Pingback'] );
		return $headers;
	}

	/** Remove ?ver= only when it equals the WordPress version (plugin and theme versions are kept for caching). */
	public static function strip_core_version( $src ) {
		global $wp_version;
		if ( $src && strpos( $src, 'ver=' . $wp_version ) !== false ) {
			$src = remove_query_arg( 'ver', $src );
		}
		return $src;
	}

	/* ---------- usernames ---------- */

	public static function block_author_scan() {
		if ( is_user_logged_in() ) {
			return;
		}
		if ( isset( $_GET['author'] ) || is_author() ) { // phpcs:ignore
			wp_safe_redirect( home_url( '/' ), 301 );
			exit;
		}
	}

	public static function rest_endpoints( $endpoints ) {
		if ( ! is_user_logged_in() ) {
			unset( $endpoints['/wp/v2/users'], $endpoints['/wp/v2/users/(?P<id>[\d]+)'] );
		}
		return $endpoints;
	}

	public static function login_error() {
		return 'Those login details are incorrect.';
	}

	public static function oembed_author( $data ) {
		unset( $data['author_name'], $data['author_url'] );
		return $data;
	}

	/* ---------- headers ---------- */

	public static function headers() {
		if ( headers_sent() ) {
			return;
		}
		header( 'X-Content-Type-Options: nosniff' );
		header( 'X-Frame-Options: SAMEORIGIN' );
		header( 'Referrer-Policy: strict-origin-when-cross-origin' );
		header( 'Permissions-Policy: camera=(), microphone=(), geolocation=(), payment=()' );
	}
}

TOKH::init();
